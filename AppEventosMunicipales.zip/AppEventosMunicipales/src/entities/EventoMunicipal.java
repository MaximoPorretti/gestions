package entities;

import commons.exepciones.ClaseExcepciones;
import commons.Utils;
import java.time.LocalDateTime;

public class EventoMunicipal {
    private String nombre;
    private String ubicacion;
    private String descripcion;
    private LocalDateTime horario;
    private static final Utils utils = new Utils();

    public EventoMunicipal(String nombre, String ubicacion, String descripcion, LocalDateTime horario) throws ClaseExcepciones {
        validarDatos(nombre, ubicacion, descripcion, horario);
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.horario = horario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        validarCampo(nombre, "exc.error.nombre_invalido");
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) throws ClaseExcepciones {
        validarCampo(ubicacion, "exc.error.ubicacion_invalido");
        this.ubicacion = ubicacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) throws ClaseExcepciones {
        validarCampo(descripcion, "exc.error.descripcion_invalido");
        this.descripcion = descripcion;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    public void setHorario(LocalDateTime horario) throws ClaseExcepciones {
        if (horario == null) {
            throw new ClaseExcepciones("exc.error.fecha_creacion_null");
        }
        this.horario = horario;
    }

    private void validarDatos(String nombre, String ubicacion, String descripcion, LocalDateTime horario) throws ClaseExcepciones {
        if (nombre == null || ubicacion == null || descripcion == null || horario == null) {
            throw new ClaseExcepciones("exc.error.campo_null");
        }
    }

    private void validarCampo(String valor, String claveError) throws ClaseExcepciones {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ClaseExcepciones(claveError);
        }
    }

    @Override
    public String toString() {
        return utils.obtenerMensaje("evento.municipal.formato")
            .replace("{nombre}", nombre)
            .replace("{ubicacion}", ubicacion)
            .replace("{descripcion}", descripcion)
            .replace("{horario}", horario.toString());
    }
}