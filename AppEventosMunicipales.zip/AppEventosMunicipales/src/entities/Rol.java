package entities;

import commons.exepciones.ClaseExcepciones;

public class Rol {
    private String nombre;

    public Rol(String nombre) throws ClaseExcepciones {
        setNombre(nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        if (nombre == null || nombre.isEmpty()) {
            throw new ClaseExcepciones("error.nombre_rol_null");
        }
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Rol[nombre=" + nombre + "]";
    }
}
