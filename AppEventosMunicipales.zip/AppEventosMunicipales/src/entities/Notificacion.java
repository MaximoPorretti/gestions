package entities;

import commons.exepciones.ClaseExcepciones;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Notificacion {
    private long id;
    private String mensaje;
    private LocalDateTime fechaCreacion;
    private Usuario usuario;

    public Notificacion(long id, String mensaje, LocalDateTime fechaCreacion, Usuario usuario) throws ClaseExcepciones {
        validarDatos(id, mensaje, fechaCreacion, usuario);
        this.id = id;
        this.mensaje = mensaje;
        this.fechaCreacion = fechaCreacion;
        this.usuario = usuario;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) throws ClaseExcepciones {
        if (id <= 0) {
            throw new ClaseExcepciones("error.id_invalido");
        }
        this.id = id;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) throws ClaseExcepciones {
        if (mensaje == null || mensaje.isEmpty()) {
            throw new ClaseExcepciones("error.mensaje_null");
        }
        this.mensaje = mensaje;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) throws ClaseExcepciones {
        if (fechaCreacion == null) {
            throw new ClaseExcepciones("error.fecha_creacion_null");
        }
        this.fechaCreacion = fechaCreacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        this.usuario = usuario;
    }

    private void validarDatos(long id, String mensaje, LocalDateTime fechaCreacion, Usuario usuario) throws ClaseExcepciones {
        if (id <= 0) {
            throw new ClaseExcepciones("error.id_invalido");
        }
        if (mensaje == null || mensaje.isEmpty()) {
            throw new ClaseExcepciones("error.mensaje_null");
        }
        if (fechaCreacion == null) {
            throw new ClaseExcepciones("error.fecha_creacion_null");
        }
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("Notificacion[id=%d, mensaje='%s', fechaCreacion='%s', usuario='%s']", 
                id, mensaje, fechaCreacion.format(formatter), usuario.getUsuario());
    }
}