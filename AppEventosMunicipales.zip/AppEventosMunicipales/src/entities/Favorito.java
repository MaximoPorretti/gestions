package entities;

import commons.exepciones.ClaseExcepciones;

public class Favorito {
    private Usuario usuario;
    private Evento evento;

    public Favorito(Usuario usuario, Evento evento) throws ClaseExcepciones {
        validarDatos(usuario, evento);
        this.usuario = usuario;
        this.evento = evento;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        this.usuario = usuario;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) throws ClaseExcepciones {
        if (evento == null) {
            throw new ClaseExcepciones("error.evento_null");
        }
        this.evento = evento;
    }

    private void validarDatos(Usuario usuario, Evento evento) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        if (evento == null) {
            throw new ClaseExcepciones("error.evento_null");
        }
    }

    @Override
    public String toString() {
        return "Favorito[usuario=" + usuario.getUsuario() + ", evento=" + evento.getNombre() + "]";
    }
}