package entities;

import commons.exepciones.ClaseExcepciones;
import java.time.LocalDateTime;

public class Evento {
    private String nombre;
    private String ubicacion;
    private String descripcion;
    private String etiqueta;
    private Usuario usuario;
    private LocalDateTime horario;
    private String estado;

    public Evento(String nombre, String ubicacion, String descripcion, String etiqueta, Usuario usuario, LocalDateTime horario, String estado) throws ClaseExcepciones {
        validarDatos(nombre, ubicacion, descripcion, etiqueta, horario, estado);
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.etiqueta = etiqueta;
        this.usuario = usuario;
        this.horario = horario;
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        validarCampo(nombre, "nombre");
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) throws ClaseExcepciones {
        validarCampo(ubicacion, "ubicacion");
        this.ubicacion = ubicacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) throws ClaseExcepciones {
        validarCampo(descripcion, "descripcion");
        this.descripcion = descripcion;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) throws ClaseExcepciones {
        validarCampo(etiqueta, "etiqueta");
        this.etiqueta = etiqueta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        this.usuario = usuario;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    public void setHorario(LocalDateTime horario) throws ClaseExcepciones {
        if (horario == null) {
            throw new ClaseExcepciones("error.horario_null");
        }
        this.horario = horario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) throws ClaseExcepciones {
        validarCampo(estado, "estado");
        this.estado = estado;
    }

    private void validarDatos(String nombre, String ubicacion, String descripcion, String etiqueta, LocalDateTime horario, String estado) throws ClaseExcepciones {
        if (nombre == null || nombre.trim().isEmpty()|| ubicacion == null || ubicacion.trim().isEmpty()
        	|| descripcion == null || descripcion.trim().isEmpty() || etiqueta == null || etiqueta.trim().isEmpty()	
        	|| horario == null) {
            throw new ClaseExcepciones("evento.entity.error__campo_null");
        }
    }

    private void validarCampo(String valor, String campo) throws ClaseExcepciones {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ClaseExcepciones("error." + campo + "_invalido");
        }
    }

    @Override
    public String toString() {
        return String.format("Evento[nombre=%s, ubicacion=%s, descripcion=%s, etiqueta=%s, usuario=%s, horario=%s, estado=%s]",
                nombre, ubicacion, descripcion, etiqueta, usuario.getUsuario(), horario, estado);
    }
}