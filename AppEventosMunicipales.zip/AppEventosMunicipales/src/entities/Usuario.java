package entities;

import commons.exepciones.ClaseExcepciones;

public class Usuario {
    private String usuario;
    private String contrasena;
    private String nombre;
    private String email;
    private Rol rol;

    public Usuario(String usuario, String contrasena, String nombre, String email, Rol rol) throws ClaseExcepciones {
        validarDatos(usuario, contrasena, nombre, email);
        if (rol == null) {
            throw new ClaseExcepciones("exc.error.rol_null");
        }
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.nombre = nombre;
        this.email = email;
        this.rol = rol;
    }

    // Getters y Setters
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) throws ClaseExcepciones {
        validarCampo(usuario, "usuario");
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) throws ClaseExcepciones {
        validarCampo(contrasena, "contrasena");
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        validarCampo(nombre, "nombre");
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws ClaseExcepciones {
        validarCampo(email, "email");
        this.email = email;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) throws ClaseExcepciones {
        if (rol == null) {
            throw new ClaseExcepciones("exc.error.rol_null");
        }
        this.rol = rol;
    }

    private void validarDatos(String... valores) throws ClaseExcepciones {
        for (String valor : valores) {
            if (valor == null || valor.trim().isEmpty()) {
                throw new ClaseExcepciones("exc.error.parametro_invalido");
            }
        }
    }

    private void validarCampo(String valor, String campo) throws ClaseExcepciones {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ClaseExcepciones("exc.error._invalido" + campo);
        }
    }

    @Override
    public String toString() {
        return String.format("Usuario[usuario=%s, nombre=%s, email=%s, rol=%s]", usuario, nombre, email, rol.getNombre());
    }
}