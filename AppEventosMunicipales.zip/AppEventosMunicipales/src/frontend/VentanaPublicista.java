package frontend;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import backend.api.PersistenceApi;
import backend.dto.EventoMunicipalDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class VentanaPublicista extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private UsuarioDTO usuarioActual;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;

    // Colores personalizados
    private final Color colorFondo = new Color(240, 255, 240);
    private final Color colorPrincipal = new Color(46, 139, 87);
    private final Color colorSecundario = new Color(60, 179, 113);
    private final Color colorTexto = Color.WHITE;

    public VentanaPublicista(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils) throws ClaseExcepciones {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils = utils;

        // Inicializar el ResourceBundle con el idioma por defecto
        labels = ResourceBundle.getBundle("labels", utils.obtenerIdiomaActual());

        configurarVentana();
        inicializarUI();
    }

    private void configurarVentana() {
     
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(colorFondo);
        setLayout(new BorderLayout());
    }

    private void inicializarUI() throws ClaseExcepciones {
        agregarBarraHerramientas();
        agregarTitulo();
        configurarTabla();
        
        // verifica si el evento se realiza el dia de hoy y se le notifica
           try {
   			persistenceApi.verificarFavoritosHoy(usuarioActual);
   		} catch (ClaseExcepciones e1) {
   			 throw new ClaseExcepciones("error.ventana_verificar_favorito");
   			
   		}
        cargarDatos();
    }

    private void agregarBarraHerramientas() {
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorPrincipal);
        panelSuperior.setBorder(new EmptyBorder(10, 10, 10, 10));

        JToolBar barraHerramientas = crearBarraHerramientas();
        panelSuperior.add(barraHerramientas, BorderLayout.CENTER);
        add(panelSuperior, BorderLayout.NORTH);
    }

    private JToolBar crearBarraHerramientas() {
        JToolBar barraHerramientas = new JToolBar();
        barraHerramientas.setFloatable(false);

        // Opciones disponibles en la barra de herramientas
        String[] opcionesMenu = {
            labels.getString("ventanaPublicista.menu.salir"),
            labels.getString("ventanaPublicista.menu.verEventos"),
            labels.getString("ventanaPublicista.menu.notificaciones"),
            labels.getString("ventanaPublicista.menu.favoritos")
        };

        for (String opcion : opcionesMenu) {
            JButton boton = new JButton(opcion);
            boton.setBackground(colorSecundario);
            boton.setForeground(colorTexto);
            boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
            boton.addActionListener(e -> manejarAccion(opcion));
            barraHerramientas.add(boton);
            barraHerramientas.addSeparator(new Dimension(10, 0));
        }

        // Crear JComboBox para cambiar el idioma
        String[] idiomas = {"Español", "Inglés"};
        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        comboBoxIdiomas.setBackground(colorSecundario);
        comboBoxIdiomas.setForeground(colorTexto);
        comboBoxIdiomas.addActionListener(e -> {
            String selectedLanguage = comboBoxIdiomas.getSelectedIndex() == 0 ? "es" : "en";
            try {
				setLanguage(selectedLanguage);
			} catch (ClaseExcepciones e1) {
				
				e1.printStackTrace();
			}
        });

        barraHerramientas.add(comboBoxIdiomas);
        return barraHerramientas;
    }

    private void agregarTitulo() {
        JLabel titulo = new JLabel(labels.getString("ventanaPublicista.tituloEventos"), SwingConstants.CENTER);
        titulo.setFont(new Font("Stencil", Font.PLAIN, 40));
        titulo.setForeground(colorPrincipal);
        add(titulo, BorderLayout.CENTER);
    }

    private void configurarTabla() {
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("ventanaPublicista.column.nombre"),
                labels.getString("ventanaPublicista.column.descripcion"),
                labels.getString("ventanaPublicista.column.ubicacion"),
                labels.getString("ventanaPublicista.column.horario")
        }, 0);

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void manejarAccion(String opcion) {
        try {
            if (opcion.equals(labels.getString("ventanaPublicista.menu.salir"))) {
                dispose();
            } else if (opcion.equals(labels.getString("ventanaPublicista.menu.verEventos"))) {
                new ListadoEventos(usuarioActual, persistenceApi, utils).setVisible(true);
            } else if (opcion.equals(labels.getString("ventanaPublicista.menu.notificaciones"))) {
                new ListadoMisNotificaciones(usuarioActual, persistenceApi, utils).setVisible(true);
            } else if (opcion.equals(labels.getString("ventanaPublicista.menu.favoritos"))) {
                new ListadoMisFavoritos(usuarioActual, persistenceApi, utils).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, labels.getString("ventanaPublicista.menu.noImplementada") + opcion);
            }
        } catch (ClaseExcepciones ex) {
            JOptionPane.showMessageDialog(this, labels.getString("ventanaPublicista.errorGeneral") + ex.getMessage(),
                    labels.getString("ventanaPublicista.dialogTitle"), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarDatos() {
        try {
            List<EventoMunicipalDTO> eventos = persistenceApi.obtenerEventosMunicipales();

            if (eventos.isEmpty()) {
                JOptionPane.showMessageDialog(this, labels.getString("ventanaPublicista.noEventos"),
                        labels.getString("ventanaPublicista.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            for (EventoMunicipalDTO evento : eventos) {
                tableModel.addRow(new Object[]{
                        evento.getNombre(),
                        evento.getDescripcion(),
                        evento.getUbicacion(),
                        evento.getHorario()
                });
            }
        } catch (ClaseExcepciones ex) {
            JOptionPane.showMessageDialog(this, labels.getString("ventanaPublicista.errorCargar") + ex.getMessage(),
                    labels.getString("ventanaPublicista.dialogTitle"), JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setLanguage(String language) throws ClaseExcepciones {
        Locale locale = new Locale(language);
        utils.establecerIdiomaActual(locale);
        labels = ResourceBundle.getBundle("labels", locale);

        // Refrescar la interfaz
        getContentPane().removeAll();
        inicializarUI();
        revalidate();
        repaint();
    }
}
