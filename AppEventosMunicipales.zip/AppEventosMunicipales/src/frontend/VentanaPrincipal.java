package frontend;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import backend.accesos.*;
import backend.api.PersistenceApi;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import backend.dto.EventoMunicipalDTO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Locale;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

public class VentanaPrincipal extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;
    // Paleta de colores verde para la interfaz
    private Color colorFondo = new Color(240, 255, 240);
    private Color colorPrincipal = new Color(46, 139, 87);
    private Color colorSecundario = new Color(60, 179, 113);
    private Color colorTexto = Color.WHITE;

    // Constructor de la clase
    public VentanaPrincipal(PersistenceApi persistenceApi, Utils utils) {
        this.persistenceApi = persistenceApi;
        this.utils = utils;
       
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondo);

        // Inicializar el idioma por defecto (español)
        setLanguage("es");
    }

    // Método para configurar los componentes de la interfaz gráfica
    private void initUI() {
        // Crear el panel superior con la barra de navegación
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorPrincipal);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Crear barra de herramientas y añadir los botones del menú
        JToolBar barraHerramientas = new JToolBar();
        barraHerramientas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        barraHerramientas.setFloatable(false);
        barraHerramientas.setOpaque(false);
        barraHerramientas.setBorderPainted(false);

        // Nombres de los elementos del menú (usando labels)
        String[] menuKeys = {
            "menuVentanaPrincipal.salir",
            "menuVentanaPrincipal.inicio-secion",
            "menuVentanaPrincipal.regis",
            "menuVentanaPrincipal.verComunidad",
            "menuVentanaPrincipal.subirEve",
            "menuVentanaPrincipal.subirPub"
        };

        for (String key : menuKeys) {
            JButton boton = new JButton(labels.getString(key));
            boton.setBackground(colorSecundario);
            boton.setForeground(colorTexto);
            boton.setFocusPainted(false);
            boton.setBorderPainted(false);
            boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
            boton.addActionListener(e -> {
                try {
                    abrirVentana(key);
                } catch (ClaseExcepciones e1) {
                    mostrarExcepcion("error.ventana_abrir");
                    e1.printStackTrace();
                }
            });
            barraHerramientas.add(boton);
            barraHerramientas.addSeparator(new Dimension(10, 0));
        }

        // Crear JComboBox para cambiar el idioma
        String[] idiomas = {"Español", "Inglés"};
        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        comboBoxIdiomas.setBackground(colorSecundario);
        comboBoxIdiomas.setForeground(colorTexto);
        comboBoxIdiomas.addActionListener(e -> {
            String selectedLanguage = comboBoxIdiomas.getSelectedIndex() == 0 ? "es" : "en";
            setLanguage(selectedLanguage);  // Cambiar el idioma con la lógica modificada
        });

        barraHerramientas.add(comboBoxIdiomas);
        panelSuperior.add(barraHerramientas, BorderLayout.CENTER);
        getContentPane().add(panelSuperior, BorderLayout.NORTH);

        // Crear la tabla y su modelo
        tableModel = new DefaultTableModel(new String[]{
            labels.getString("menuVentanaPrincipal.municipalnombre"),
            labels.getString("menuVentanaPrincipal.municipaldescripcion"),
            labels.getString("menuVentanaPrincipal.municipalubicacion"),
            labels.getString("menuVentanaPrincipal.municipalfechahora")
        }, 0);
        table = new JTable(tableModel);
        table.setEnabled(false);
        table.setBackground(Color.WHITE);
        table.setForeground(Color.BLACK);
        table.setFont(new Font("MS UI Gothic", Font.BOLD, 10));
        table.setBorder(new MatteBorder(1, 1, 1, 1, new Color(0, 128, 0)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new LineBorder(new Color(0, 128, 0), 5));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        getContentPane().add(scrollPane, BorderLayout.SOUTH);

        JLabel lblTitulo = new JLabel(labels.getString("menuVentanaPrincipal.verEstado"));
        lblTitulo.setBackground(new Color(0, 128, 0));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setForeground(new Color(0, 128, 0));
        lblTitulo.setFont(new Font("Stencil", Font.PLAIN, 50));
        getContentPane().add(lblTitulo, BorderLayout.CENTER);

        cargarDatos(); // Cargar los datos de eventos municipales
    }

    // Método para cambiar el idioma
    private void setLanguage(String language) {
        Locale locale = new Locale(language);
        // Establecer el idioma actual usando el método del backend
        utils.establecerIdiomaActual(locale);  // Llamada al método establecerIdiomaActual

        // Cargar los recursos del idioma
        labels = ResourceBundle.getBundle("labels", locale);
        
        // Limpiar la ventana y volver a inicializar la interfaz con el nuevo idioma
        getContentPane().removeAll();
        initUI();
        revalidate();
        repaint();
    }

    private void mostrarExcepcion(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Método que abre diferentes ventanas en función de la opción seleccionada
    private void abrirVentana(String key) throws ClaseExcepciones {
        String opcion = labels.getString(key);
        switch (key) {
            case "menuVentanaPrincipal.inicio-secion":
                new VentanaInicioSesion(persistenceApi, utils).setVisible(true);
                dispose();
                break;
            case "menuVentanaPrincipal.regis":
                new AltaUsuario(persistenceApi, utils).setVisible(true);
                break;
            case "menuVentanaPrincipal.verComunidad":
                new ListadoEventos(null, persistenceApi, utils).setVisible(true);
                break;
            case "menuVentanaPrincipal.subirEve":
                JOptionPane.showMessageDialog(this, labels.getString("menuVentanaPrincipal.nosesionevento"));
                break;
            case "menuVentanaPrincipal.subirPub":
                JOptionPane.showMessageDialog(this, labels.getString("menuVentanaPrincipal.nosesionanuncio"));
                break;
            case "menuVentanaPrincipal.salir":
                dispose();
                break;
            default:
                JOptionPane.showMessageDialog(this, labels.getString("menuVentanaPrincipal.errornoimplementado") + opcion);
        }
    }

    public void cargarDatos() {
        try {
            List<EventoMunicipalDTO> eventos = persistenceApi.obtenerEventosMunicipales();
            
            // Crear un formateador para el formato deseado (fecha y hora)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            
            for (EventoMunicipalDTO evento : eventos) {
                // Obtener el horario del evento como LocalDateTime y formatearlo
                String fechaYHora = evento.getHorario().format(formatter);  // Formateamos el LocalDateTime
                
                // Agregar la fila con la fecha y hora formateada
                tableModel.addRow(new Object[]{
                    evento.getNombre(),
                    evento.getDescripcion(),
                    evento.getUbicacion(),
                    fechaYHora  // Mostramos la fecha y hora formateada
                });
            }
        } catch (ClaseExcepciones e) {
            mostrarExcepcion(labels.getString("menuVentanaPrincipal.errormunicipal"));
            e.printStackTrace();
        }
    }



    public static void main(String[] args) {
        Utils utils = new Utils();
        // Crear instancia de PersistenceApi y pasarla al constructor
        PersistenceApi persistenceAPI = new PersistenceApi(new EventoDAOJDBC(), new EventoMunicipalDAOJDBC(), new UsuarioDAOJDBC(), new RolDAOJDBC(), new NotificacionDAOJDBC(), new FavoritosDAOJDBC());
        SwingUtilities.invokeLater(() -> {
            VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(persistenceAPI, utils);
            ventanaPrincipal.setVisible(true);
        });
    }
}