package frontend;

import backend.api.PersistenceApi;
import backend.dto.EventoDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;
import javax.swing.border.MatteBorder;

public class ListadoEventos extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi;
    private UsuarioDTO usuarioActual;
    private ResourceBundle labels;
    private Utils utils;

    public ListadoEventos(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils ) throws ClaseExcepciones {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils= utils;

        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        // Configuración de la ventana
        setTitle(labels.getString("menuListadoEventos.sistema"));
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear la tabla y su modelo
        tableModel = new DefaultTableModel(new String[] {
                labels.getString("menuListadoEventos.nombre"),
                labels.getString("menuListadoEventos.descripcion"),
                labels.getString("menuListadoEventos.ubicacion"),
                labels.getString("menuListadoEventos.etiqueta"),
                labels.getString("menuListadoEventos.fechahora"),
                labels.getString("menuListadoEventos.usuario")
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        getContentPane().setLayout(new BorderLayout(0, 0));
        table = new JTable(tableModel);
        table.setForeground(new Color(107, 142, 35));
        table.setBorder(new MatteBorder(1, 1, 1, 1, new Color(0, 100, 0)));
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new MatteBorder(1, 1, 1, 1, new Color(0, 128, 0)));
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Cargar datos en la tabla
        cargarDatos();

        // Panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new MatteBorder(1, 1, 1, 1, new Color(0, 128, 64)));

        // Botón Cerrar
        JButton btnCerrar = new JButton(labels.getString("menuListadoEventos.cerrar"));
        btnCerrar.addActionListener(e -> dispose());
        buttonPanel.add(btnCerrar);

        // Botón Agregar a Favoritos
        JButton btnFavoritos = new JButton(labels.getString("menuListadoEventos.agregarfavorito"));
        btnFavoritos.addActionListener(e -> agregarAFavoritos());
        buttonPanel.add(btnFavoritos);

        table.setShowGrid(true);
        table.setGridColor(Color.LIGHT_GRAY);

        // Agregar los botones al panel
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        JLabel lblNewLabel = new JLabel(labels.getString("menuListadoEventos.titulo"));
        lblNewLabel.setForeground(new Color(0, 128, 0));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("MS UI Gothic", Font.BOLD, 26));
        getContentPane().add(lblNewLabel, BorderLayout.NORTH);
    }

    private void cargarDatos() throws ClaseExcepciones {
        List<EventoDTO> eventos = persistenceApi.obtenerEventos();
        for (EventoDTO evento : eventos) {
           if ("Aprobado".equals(evento.getEstado()) || "Approved".equals(evento.getEstado())) {
                tableModel.addRow(new Object[]{
                        evento.getNombre(),
                        evento.getDescripcion(),
                        evento.getUbicacion(),
                        evento.getEtiqueta(),
                        evento.getHorario(),
                        evento.getUsuario().getUsuario()
                });
            }
        }
    }

    private void agregarAFavoritos() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            try {
                String nombreEvento = (String) table.getValueAt(selectedRow, 0);
              
                if (usuarioActual == null || usuarioActual.getUsuario() == null) {
                    JOptionPane.showMessageDialog(this,
                            labels.getString("menuListadoEventos.errorusuarionoiniciado"),
                            labels.getString("menuListadoEventos.errorcrear"),
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (persistenceApi.yaEstaEnFavoritos(usuarioActual, nombreEvento)) {
                    JOptionPane.showMessageDialog(this,
                            labels.getString("menuListadoEventos.mensajeevento") +" " + nombreEvento + " "
                                  +  labels.getString("menuListadoEventos.mensajeeventoexistente"),
                            labels.getString("menuListadoEventos.informacion"),
                            JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // Agregar a favoritos
                persistenceApi.agregarFavorito(usuarioActual.getUsuario(), nombreEvento);
                LocalDateTime now = LocalDateTime.now();     
                Random random = new Random();
                long randomInt = random.nextInt(100);
                persistenceApi.nuevaNotificacion(labels.getString("menuListadoEventos.mensajeAntes") +"  \""+ nombreEvento + "\" " +labels.getString("menuListadoEventos.mensajeDespues"),usuarioActual.getUsuario(),now );
                JOptionPane.showMessageDialog(this,
                        labels.getString("menuListadoEventos.favoritoagregado"));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        labels.getString("menuListadoEventos.errorcrear") + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                    labels.getString("menuListadoEventos.seleccionfavoritos"));
        }
    }
}
