package frontend;

import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import backend.api.PersistenceApi;
import backend.dto.EventoDTO;
import backend.dto.UsuarioDTO;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class ListadoMisEventos extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private List<EventoDTO> eventos;
    private UsuarioDTO usuarioActual;
    private PersistenceApi api;  
    private ResourceBundle labels;  // Añadido para usar ResourceBundle
    private Utils utils;
    public ListadoMisEventos(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils ) {
        this.usuarioActual = usuarioActual;
        this.api = persistenceApi;
        this.utils= utils;
        
  
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual =  utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        eventos = new ArrayList<>(); // Inicializamos la lista de eventos

        // Configuración de la ventana
        setTitle(labels.getString("listadoEventos.titulo") + ": " + usuarioActual.getNombre());  // Usar ResourceBundle para el título
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Título con el nombre del usuario
        JLabel lblTitulo = new JLabel(labels.getString("listadoEventos.titulo") + ": " + usuarioActual.getNombre(), JLabel.CENTER);
        lblTitulo.setFont(new Font("MS UI Gothic", Font.BOLD, 24));
        lblTitulo.setForeground(new Color(0, 128, 0));  // Color verde
        getContentPane().add(lblTitulo, BorderLayout.NORTH);

        // Crear la tabla y su modelo con las columnas correspondientes
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("listadoEventos.column.nombre"),
                labels.getString("listadoEventos.column.descripcion"),
                labels.getString("listadoEventos.column.ubicacion"),
                labels.getString("listadoEventos.column.etiqueta"),
                labels.getString("listadoEventos.column.horario"),
                labels.getString("listadoEventos.column.usuario"),
                labels.getString("listadoEventos.column.estado")
        }, 0);

        table = new JTable(tableModel);
        table.setBorder(new LineBorder(new Color(0, 128, 0)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Selección única
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setViewportBorder(new LineBorder(new Color(0, 100, 0)));
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Cargar datos en la tabla
        cargarDatos();

        // Panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new LineBorder(new Color(34, 139, 34), 13));
        buttonPanel.setForeground(new Color(0, 128, 0));

        JButton btnCerrar = new JButton(labels.getString("listadoEventos.btnCerrar"));
        btnCerrar.addActionListener(e -> dispose());
        buttonPanel.add(btnCerrar);

        // Botón de eliminar
        JButton btnEliminar = new JButton(labels.getString("listadoEventos.btnEliminar"));
        buttonPanel.add(btnEliminar);

        // Acción de eliminar
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEventoSeleccionado(); // Llama al método para eliminar el evento seleccionado
            }
        });


        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        table.setGridColor(Color.LIGHT_GRAY);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    // Cargar datos en la tabla desde la lista de eventos
    public void cargarDatos() {
        try {
            // Recuperamos los eventos del usuario actual a través de PersistenceApi
            List<EventoDTO> eventosUsuario = api.obtenerEventosDelUsuario(usuarioActual);

            if (eventosUsuario.isEmpty()) {
                JOptionPane.showMessageDialog(this, labels.getString("listadoEventos.noEventos"));
            }

            // Agregar los eventos a la tabla
            for (EventoDTO evento : eventosUsuario) {
                tableModel.addRow(new Object[]{
                        evento.getNombre(),
                        evento.getDescripcion(),
                        evento.getUbicacion(),
                        evento.getEtiqueta(),
                        evento.getHorario(),
                        evento.getUsuario().getUsuario(),
                        evento.getEstado()
                });
            }
        } catch (ClaseExcepciones e) {
            JOptionPane.showMessageDialog(this, labels.getString("listadoEventos.errorCargar") + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para eliminar el evento seleccionado de la lista y de la base de datos
    public void eliminarEventoSeleccionado() {
        int selectedRow = table.getSelectedRow(); // Obtener la fila seleccionada

        if (selectedRow != -1) {
            String nombreEvento = (String) table.getValueAt(selectedRow, 0); // Obtener el nombre del evento

            try {
            	api.eliminarDeMisFavoritos(nombreEvento);
            	// Eliminar el evento de la base de datos
                api.eliminarEvento(nombreEvento);

                // Eliminar la fila de la tabla
                tableModel.removeRow(selectedRow);

                JOptionPane.showMessageDialog(this, labels.getString("listadoEventos.eventoEliminado"));
            } catch (ClaseExcepciones e) {
                JOptionPane.showMessageDialog(this, labels.getString("listadoEventos.errorEliminar") + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, labels.getString("listadoEventos.seleccioneEvento"));
        }
    }
}
