package frontend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;

import backend.api.PersistenceApi;
import backend.dto.EventoDTO;
import backend.dto.NotificacionDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;

public class AltaEvento extends JFrame {
    private JTextField txtNombre;
    private JTextField txtUbicacion;
    private JTextField txtDescripcion;
    private JComboBox<String> comboBoxCategorias;
    private JSpinner dateSpinner; // Spinner para la selección de fecha
    private JSpinner timeSpinner;  // Para la selección de la hora
    private UsuarioDTO usuarioActual;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;

    public AltaEvento(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils) {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils = utils;

        // Obtener el idioma actual desde Utils
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        setType(Type.UTILITY);
        getContentPane().setBackground(new Color(102, 153, 51));
        initialize();
    }

    private void initialize() {
        setTitle(labels.getString("menuAltaEvento.sistema"));
        setSize(508, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNombre = new JLabel(labels.getString("menuAltaEvento.nombre"));
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setBounds(30, 30, 148, 25);
        getContentPane().add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(171, 30, 200, 25);
        getContentPane().add(txtNombre);

        JLabel lblUbicacion = new JLabel(labels.getString("menuAltaEvento.ubicacion"));
        lblUbicacion.setForeground(Color.WHITE);
        lblUbicacion.setBounds(30, 70, 148, 25);
        getContentPane().add(lblUbicacion);

        txtUbicacion = new JTextField();
        txtUbicacion.setBounds(171, 70, 200, 25);
        getContentPane().add(txtUbicacion);

        JLabel lblDescripcion = new JLabel(labels.getString("menuAltaEvento.descripcion"));
        lblDescripcion.setForeground(Color.WHITE);
        lblDescripcion.setBounds(30, 110, 148, 25);
        getContentPane().add(lblDescripcion);

        txtDescripcion = new JTextField();
        txtDescripcion.setBounds(171, 110, 200, 25);
        getContentPane().add(txtDescripcion);

        JLabel lblCategoria = new JLabel(labels.getString("menuAltaEvento.categorias"));
        lblCategoria.setForeground(Color.WHITE);
        lblCategoria.setBounds(30, 150, 148, 25);
        getContentPane().add(lblCategoria);

        comboBoxCategorias = new JComboBox<>(new String[]{
                labels.getString("menuAltaEvento.etiquetadeporte"),
                labels.getString("menuAltaEvento.etiquetamusica"),
                labels.getString("menuAltaEvento.etiquetacultural"),
                labels.getString("menuAltaEvento.etiquetagastronomica")
        });
        comboBoxCategorias.setBounds(171, 150, 200, 25);
        getContentPane().add(comboBoxCategorias);

        JLabel lblFecha = new JLabel(labels.getString("menuAltaEvento.fecha"));
        lblFecha.setForeground(Color.WHITE);
        lblFecha.setBounds(30, 190, 148, 25);
        getContentPane().add(lblFecha);

        // Spinner para la selección de fecha
        SpinnerDateModel dateModel = new SpinnerDateModel();
        dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "dd/MM/yyyy");
        dateSpinner.setEditor(dateEditor);
        dateSpinner.setBounds(171, 190, 200, 25);
        getContentPane().add(dateSpinner);

        JLabel lblHora = new JLabel(labels.getString("menuAltaEvento.horario"));
        lblHora.setForeground(Color.WHITE);
        lblHora.setBounds(30, 230, 148, 25);
        getContentPane().add(lblHora);

        // Selector de hora (JSpinner)
        SpinnerDateModel timeModel = new SpinnerDateModel();
        timeSpinner = new JSpinner(timeModel);
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
        timeSpinner.setEditor(timeEditor);
        timeSpinner.setBounds(171, 230, 90, 25);
        getContentPane().add(timeSpinner);

        JButton btnRegistrar = new JButton(labels.getString("menuAltaEvento.crear"));
        btnRegistrar.setForeground(new Color(154, 205, 50));
        btnRegistrar.setBounds(171, 280, 150, 25);
        btnRegistrar.addActionListener(this::onRegistrarClick);
        getContentPane().add(btnRegistrar);

        JButton btnCerrar = new JButton(labels.getString("menuAltaEvento.salir"));
        btnCerrar.setForeground(new Color(154, 205, 50));
        btnCerrar.setBounds(331, 280, 90, 25);
        btnCerrar.addActionListener(e -> dispose());
        getContentPane().add(btnCerrar);
    }

    private void onRegistrarClick(ActionEvent e) {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    String nombre = Optional.ofNullable(txtNombre.getText()).filter(n -> !n.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menuAltaEvento.errornombrevacio")));
                    String ubicacion = Optional.ofNullable(txtUbicacion.getText()).filter(u -> !u.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menuAltaEvento.errorubicacionvacia")));
                    String descripcion = Optional.ofNullable(txtDescripcion.getText()).filter(d -> !d.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menuAltaEvento.errordescripcionvacia")));
                    String categoriaSeleccionada = Optional.ofNullable((String) comboBoxCategorias.getSelectedItem())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menuAltaEvento.errorcategoriavacia")));
                    Date fechaSeleccionada = (Date) dateSpinner.getValue();
                    if (fechaSeleccionada == null) {
                        throw new IllegalArgumentException(labels.getString("menuAltaEvento.errorfechavacia"));
                    }

                    Date horaSeleccionada = (Date) timeSpinner.getValue();
                    if (horaSeleccionada == null) {
                        throw new IllegalArgumentException(labels.getString("menuAltaEvento.errorhoravacia"));
                    }


                    // Convertir a LocalDate y LocalTime
                    LocalDate fecha = fechaSeleccionada.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                    LocalTime hora = horaSeleccionada.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalTime();

                    // Combinar en LocalDateTime
                    LocalDateTime fechaHora = LocalDateTime.of(fecha, hora);

                    // Validar que la fecha y hora no sean anteriores al momento actual
                    if (fechaHora.isBefore(LocalDateTime.now())) {
                        throw new IllegalArgumentException(labels.getString("menuAltaEvento.errorfechaPasada"));
                    }

                    if (usuarioActual == null) {
                        throw new IllegalStateException(labels.getString("menuAltaEvento.errorusuarioinexistente"));
                    }

                    // Registrar el evento
                    EventoDTO evento = new EventoDTO(
                            nombre, ubicacion, descripcion, categoriaSeleccionada, fechaHora, usuarioActual, labels.getString("menuAltaEvento.pendiente")
                    );
                    persistenceApi.registrarEvento(evento);

                    // Crear notificación
                    persistenceApi.nuevaNotificacion( 
                            labels.getString("menuAltaEvento.mensaje1") + nombre + labels.getString("menuAltaEvento.mensaje2"),usuarioActual.getUsuario(),
                            LocalDateTime.now());

                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(null, labels.getString("menuAltaEvento.crearexitoso"));
                        dispose();
                    });
                } catch (IllegalArgumentException | IllegalStateException ex) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, ex.getMessage()));
                }catch (ClaseExcepciones ex) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, ex.getMessage(), "menuAltaEvento.errorgenerico", JOptionPane.ERROR_MESSAGE));
                    ex.printStackTrace(); 
                }
                return null;
            }
        };
        worker.execute();
    }
}
