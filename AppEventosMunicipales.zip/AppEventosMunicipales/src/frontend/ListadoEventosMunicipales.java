package frontend;

import backend.api.PersistenceApi;
import backend.dto.EventoMunicipalDTO;
import commons.Utils;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class ListadoEventosMunicipales extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceAPI;
    private ResourceBundle labels;
    private Utils utils;
    public ListadoEventosMunicipales( PersistenceApi persistenceApi, Utils utils ) {
        this.persistenceAPI = persistenceApi;
        this.utils= utils;
        
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);


        // Configuración de la ventana
        setTitle(labels.getString("listadoEventosMunicipales.titulo"));
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Configuración de la tabla
        configurarTabla();

        // Panel con botones
        JPanel buttonPanel = crearPanelBotones();
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        // Cargar datos en la tabla
        cargarDatos();
    }

    // Método para configurar la tabla
    private void configurarTabla() {
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("listadoEventosMunicipales.column.nombre"),
                labels.getString("listadoEventosMunicipales.column.descripcion"),
                labels.getString("listadoEventosMunicipales.column.ubicacion"),
                labels.getString("listadoEventosMunicipales.column.horario")
        }, 0);

        table = new JTable(tableModel);
        table.setToolTipText("");
        table.setForeground(new Color(0, 0, 0));
        table.setBackground(new Color(255, 255, 255));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setBorder(new LineBorder(new Color(0, 128, 0)));
        table.setFillsViewportHeight(true);
        table.setGridColor(new Color(154, 205, 50));

        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    // Método para crear panel de botones
    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(0, 128, 0), 10));

        JButton btnCerrar = new JButton(labels.getString("listadoEventosMunicipales.btnCerrar"));
        btnCerrar.addActionListener(e -> dispose());

        JButton btnEliminar = new JButton(labels.getString("listadoEventosMunicipales.btnEliminar"));
        btnEliminar.addActionListener(e -> eliminarEvento());

        panel.add(btnCerrar);
        panel.add(btnEliminar);
        return panel;
    }

    // Método para cargar datos en la tabla
    private void cargarDatos() {
        try {
            List<EventoMunicipalDTO> eventos = persistenceAPI.obtenerEventosMunicipales();
            tableModel.setRowCount(0); // Limpiar la tabla
            if (eventos.isEmpty()) {
                JOptionPane.showMessageDialog(this, labels.getString("listadoEventosMunicipales.noEventos"),
                        labels.getString("listadoEventosMunicipales.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
            } else {
                eventos.forEach(evento -> tableModel.addRow(new Object[]{
                        evento.getNombre(),
                        evento.getDescripcion(),
                        evento.getUbicacion(),
                        evento.getHorario()
                }));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, labels.getString("listadoEventosMunicipales.errorCargar") + e.getMessage(),
                    labels.getString("listadoEventosMunicipales.dialogTitle"), JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para eliminar un evento
    private void eliminarEvento() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String nombreEvento = (String) table.getValueAt(selectedRow, 0);
            try {
                persistenceAPI.eliminarEventoMunicipal(nombreEvento);
                tableModel.removeRow(selectedRow); // Actualiza la tabla sin recargar todos los datos
                JOptionPane.showMessageDialog(this, labels.getString("listadoEventosMunicipales.eventoEliminado"),
                        labels.getString("listadoEventosMunicipales.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, labels.getString("listadoEventosMunicipales.errorEliminar") + e.getMessage(),
                        labels.getString("listadoEventosMunicipales.dialogTitle"), JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, labels.getString("listadoEventosMunicipales.seleccioneEvento"),
                    labels.getString("listadoEventosMunicipales.dialogTitle"), JOptionPane.WARNING_MESSAGE);
        }
    }
}