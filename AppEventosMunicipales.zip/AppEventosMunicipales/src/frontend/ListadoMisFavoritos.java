package frontend;

import backend.api.PersistenceApi;
import backend.dto.EventoDTO;
import backend.dto.FavoritoDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class ListadoMisFavoritos extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi;
    private UsuarioDTO usuarioActual;
    private ResourceBundle labels;
    private Utils utils;
    public ListadoMisFavoritos(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils ) throws ClaseExcepciones {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);


        // Configuración de la ventana
        setTitle(labels.getString("listadoMisFavoritos.titulo"));
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Crear tabla
        configurarTabla();

        // Panel con botones
        JPanel buttonPanel = crearPanelBotones();

        // Cargar datos en la tabla
        cargarDatos();

        // Agregar componentes
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    private void configurarTabla() {
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("listadoMisFavoritos.column.nombre"),
                labels.getString("listadoMisFavoritos.column.ubicacion"),
                labels.getString("listadoMisFavoritos.column.descripcion"),
                labels.getString("listadoMisFavoritos.column.horario"),
                labels.getString("listadoMisFavoritos.column.etiqueta"),
                labels.getString("listadoMisFavoritos.column.usuarioCreador")
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setBorder(new LineBorder(new Color(0, 128, 64)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        table.setGridColor(new Color(0, 128, 0));

        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(0, 128, 0), 13));

        JButton btnCerrar = new JButton(labels.getString("listadoMisFavoritos.btnCerrar"));
        btnCerrar.addActionListener(e -> dispose());
        panel.add(btnCerrar);

        JButton btnEliminar = new JButton(labels.getString("listadoMisFavoritos.btnEliminar"));
        btnEliminar.addActionListener(e -> eliminarEventoFavorito());
        panel.add(btnEliminar);

        return panel;
    }
    private void cargarDatos() throws ClaseExcepciones {
        List<EventoDTO> eventos = persistenceApi.MisFavoritos(usuarioActual);
        for (EventoDTO evento : eventos) {
         //   if ("Aprobado".equals(evento.getEstado()) || "Approved".equals(evento.getEstado())) {
                tableModel.addRow(new Object[]{
                        evento.getNombre(),
                        evento.getDescripcion(),
                        evento.getUbicacion(),
                        evento.getEtiqueta(),
                        evento.getHorario(),
                        evento.getUsuario().getUsuario()
                });
         //   }
        }
    
        }
    

    private void eliminarEventoFavorito() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow != -1) {
            String nombreEvento = (String) table.getValueAt(selectedRow, 0);

            try {
                persistenceApi.eliminarFavorito(usuarioActual.getUsuario(), nombreEvento);
                tableModel.removeRow(selectedRow);

                JOptionPane.showMessageDialog(this, labels.getString("listadoMisFavoritos.eventoEliminado"),
                        labels.getString("listadoMisFavoritos.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
            } catch (ClaseExcepciones ex) {
                JOptionPane.showMessageDialog(this, labels.getString("listadoMisFavoritos.errorEliminar") + ex.getMessage(),
                        labels.getString("listadoMisFavoritos.dialogTitle"), JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, labels.getString("listadoMisFavoritos.seleccioneEvento"),
                    labels.getString("listadoMisFavoritos.dialogTitle"), JOptionPane.WARNING_MESSAGE);
        }
    }
}
