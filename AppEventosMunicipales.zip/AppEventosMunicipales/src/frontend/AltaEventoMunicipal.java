
package frontend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import backend.api.PersistenceApi;
import backend.dto.EventoMunicipalDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import java.awt.event.ActionListener;

public class AltaEventoMunicipal extends JFrame {
    private JTextField txtNombre;
    private JTextField txtUbicacion;
    private JTextField txtDescripcion;
    private JSpinner dateSpinner;
    private JSpinner timeSpinner;
    private UsuarioDTO usuarioActual;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;
    private static final ZoneId ZONA_LOCAL = ZoneId.of("America/Argentina/Buenos_Aires"); // Zona horaria

    public AltaEventoMunicipal(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils ) {
        getContentPane().setBackground(new Color(154, 205, 50));
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils = utils;

        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        initialize();
    }

    private void initialize() {
        setTitle(labels.getString("menualtaMunicipal.sistema"));
        setSize(508, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNombre = new JLabel(labels.getString("menualtaMunicipal.nombre"));
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setBounds(30, 30, 150, 25);
        getContentPane().add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(171, 30, 200, 25);
        getContentPane().add(txtNombre);

        JLabel lblUbicacion = new JLabel(labels.getString("menualtaMunicipal.ubicacion"));
        lblUbicacion.setForeground(Color.WHITE);
        lblUbicacion.setBounds(30, 70, 80, 25);
        getContentPane().add(lblUbicacion);

        txtUbicacion = new JTextField();
        txtUbicacion.setBounds(171, 70, 200, 25);
        getContentPane().add(txtUbicacion);

        JLabel lblDescripcion = new JLabel(labels.getString("menualtaMunicipal.descripcion"));
        lblDescripcion.setForeground(Color.WHITE);
        lblDescripcion.setBounds(30, 110, 100, 25);
        getContentPane().add(lblDescripcion);

        txtDescripcion = new JTextField();
        txtDescripcion.setBounds(171, 110, 200, 25);
        getContentPane().add(txtDescripcion);

        JLabel lblFecha = new JLabel(labels.getString("menualtaMunicipal.fecha"));
        lblFecha.setForeground(Color.WHITE);
        lblFecha.setBounds(30, 150, 100, 25);
        getContentPane().add(lblFecha);

        dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "dd/MM/yyyy");
        dateSpinner.setEditor(dateEditor);
        dateSpinner.setBounds(171, 150, 200, 25);
        getContentPane().add(dateSpinner);

        JLabel lblHora = new JLabel(labels.getString("menualtaMunicipal.horario"));
        lblHora.setForeground(Color.WHITE);
        lblHora.setBounds(30, 190, 100, 25);
        getContentPane().add(lblHora);

        timeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm");
        timeSpinner.setEditor(timeEditor);
        timeSpinner.setBounds(171, 190, 100, 25);
        getContentPane().add(timeSpinner);

        JButton btnRegistrar = new JButton(labels.getString("menualtaMunicipal.crear"));
        btnRegistrar.setForeground(new Color(51, 102, 51));
        btnRegistrar.setBounds(271, 360, 100, 25);
        btnRegistrar.addActionListener(this::onRegistrarClick);
        getContentPane().add(btnRegistrar);

        JButton btnCerrar = new JButton(labels.getString("menualtaMunicipal.cerrar"));
        btnCerrar.addActionListener(e -> dispose());
        btnCerrar.setForeground(new Color(51, 102, 51));
        btnCerrar.setBounds(171, 360, 90, 25);
        getContentPane().add(btnCerrar);
    }

    private void onRegistrarClick(ActionEvent e) {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() {
                try {
                    String nombre = Optional.ofNullable(txtNombre.getText()).filter(n -> !n.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menualtaMunicipal.errornombrevacio")));
                    String ubicacion = Optional.ofNullable(txtUbicacion.getText()).filter(u -> !u.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menualtaMunicipal.errorubicacionvacia")));
                    String descripcion = Optional.ofNullable(txtDescripcion.getText()).filter(d -> !d.isEmpty())
                            .orElseThrow(() -> new IllegalArgumentException(labels.getString("menualtaMunicipal.errordescripcionvacia")));
                    Date fechaSeleccionada = (Date) dateSpinner.getValue();
                    if (fechaSeleccionada == null) {
                        throw new IllegalArgumentException(labels.getString("menualtaMunicipal.errorfechavacia"));
                    }

                    Date horaSeleccionada = (Date) timeSpinner.getValue();
                    if (horaSeleccionada == null) {
                        throw new IllegalArgumentException(labels.getString("menualtaMunicipal.errorhoravacia"));
                    }

                    // Convertir a LocalDate y LocalTime
                    LocalDate fecha = fechaSeleccionada.toInstant().atZone(ZONA_LOCAL).toLocalDate();
                    LocalTime hora = horaSeleccionada.toInstant().atZone(ZONA_LOCAL).toLocalTime();

                    // Combinar en LocalDateTime
                    LocalDateTime fechaHora = LocalDateTime.of(fecha, hora);

                    // Validar que la fecha y hora no sean anteriores al momento actual
                    if (fechaHora.isBefore(LocalDateTime.now())) {
                        throw new IllegalArgumentException(labels.getString("menualtaMunicipal.errorfechaPasada"));
                    }

                    if (usuarioActual == null) {
                        throw new IllegalStateException(labels.getString("menualtaMunicipal.errorusuarioinexistente"));
                    }

                    // Registrar el evento municipal
                    EventoMunicipalDTO eventoMunicipal = new EventoMunicipalDTO(
                            nombre, ubicacion, descripcion, fechaHora
                    );
                    persistenceApi.registrarEventoMunicipal(eventoMunicipal);

                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(null, labels.getString("menualtaMunicipal.crearexitoso"));
                        dispose();
                    });
                } catch (IllegalArgumentException | IllegalStateException ex) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, ex.getMessage()));
                } catch (ClaseExcepciones ex) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, ex.getMessage(), "menuAltaEvento.errorgenerico", JOptionPane.ERROR_MESSAGE));
                    ex.printStackTrace();
                }
                return null;
            }
        };
        worker.execute();
    }
}
