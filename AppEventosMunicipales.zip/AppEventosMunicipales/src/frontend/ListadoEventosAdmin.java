package frontend;

import backend.api.PersistenceApi;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import backend.dto.EventoDTO;
import backend.dto.NotificacionDTO;
import backend.dto.UsuarioDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;

public class ListadoEventosAdmin extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;
    // Constructor
    public ListadoEventosAdmin(PersistenceApi persistenceApi, Utils utils ) {

        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        // Configuración inicial de la ventana
        setTitle(labels.getString("listadoEventosAdmin.titulo"));
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Configurar la tabla
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("listadoEventosAdmin.column.nombre"),
                labels.getString("listadoEventosAdmin.column.descripcion"),
                labels.getString("listadoEventosAdmin.column.ubicacion"),
                labels.getString("listadoEventosAdmin.column.etiqueta"),
                labels.getString("listadoEventosAdmin.column.horario"),
                labels.getString("listadoEventosAdmin.column.usuario"),
                labels.getString("listadoEventosAdmin.column.estado")
        }, 0);
        table = new JTable(tableModel);
        table.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 0)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel buttonPanel = crearPanelBotones();
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        // Cargar datos
        cargarDatos();
    }

    // Método para cargar datos en la tabla
    private void cargarDatos() {
        try {
            List<EventoDTO> eventos = persistenceApi.obtenerEventos();
            if (eventos.isEmpty()) {
                mostrarMensaje(labels.getString("listadoEventosAdmin.noEventos"));
            } else {
                for (EventoDTO evento : eventos) {
                    tableModel.addRow(new Object[]{
                            evento.getNombre(),
                            evento.getDescripcion(),
                            evento.getUbicacion(),
                            evento.getEtiqueta(),
                            evento.getHorario(),
                            evento.getUsuario().getUsuario(),
                            evento.getEstado()
                    });
                }
            }
        } catch (ClaseExcepciones e) {
            mostrarMensaje(labels.getString("listadoEventosAdmin.errorCargar") + e.getMessage());
            e.printStackTrace();
        }
    }

    // Crear panel con botones de acción
    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel();

        JButton btnCerrar = new JButton(labels.getString("listadoEventosAdmin.btnCerrar"));
        btnCerrar.addActionListener(e -> dispose());

        JButton btnEliminar = new JButton(labels.getString("listadoEventosAdmin.btnEliminar"));
        btnEliminar.addActionListener(e -> eliminarEvento());

        JButton btnAprobar = new JButton(labels.getString("listadoEventosAdmin.btnAprobar"));
        btnAprobar.addActionListener(e -> aprobarEvento());

        panel.add(btnCerrar);
        panel.add(btnEliminar);
        panel.add(btnAprobar);
        return panel;
    }

    // Método para eliminar un evento seleccionado
    private void eliminarEvento() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String nombreEvento = (String) table.getValueAt(selectedRow, 0);
            String usuarioEvento = (String) table.getValueAt(selectedRow, 5);
            try {                
                persistenceApi.eliminarDeMisFavoritos(nombreEvento);
                persistenceApi.eliminarEvento(nombreEvento);
                tableModel.removeRow(selectedRow);
              
                LocalDateTime now = LocalDateTime.now();
              
             
                persistenceApi.nuevaNotificacion(String.format(labels.getString("listadoEventosAdmin.notificacionEliminado"),nombreEvento),usuarioEvento ,now);
 
                mostrarMensaje(labels.getString("listadoEventosAdmin.eventoEliminado"));
            } catch (ClaseExcepciones e) {
                mostrarMensaje(labels.getString("listadoEventosAdmin.errorEliminar") + e.getMessage());
            }
        } else {
            mostrarMensaje(labels.getString("listadoEventosAdmin.seleccioneEvento"));
        }
    }

    // Método para aprobar un evento seleccionado
    private void aprobarEvento() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String nombreEvento = (String) table.getValueAt(selectedRow, 0);
            String usuarioEvento = (String) table.getValueAt(selectedRow, 5);
            String estadoActual = (String) table.getValueAt(selectedRow, 6);

            if ("Aprobado".equalsIgnoreCase(estadoActual) ||"Approved".equalsIgnoreCase(estadoActual)) {
                mostrarMensaje(labels.getString("listadoEventosAdmin.yaAprobado"));
                return;
            }

            try {
                persistenceApi.actualizarEstado(nombreEvento, labels.getString( "listadoEventosAdmin.Aprobado"));
                table.setValueAt(labels.getString( "listadoEventosAdmin.Aprobado"), selectedRow, 6);
                LocalDateTime now = LocalDateTime.now();
                
               
                persistenceApi.nuevaNotificacion( String.format(labels.getString("listadoEventosAdmin.notificacionAprobado"), nombreEvento),usuarioEvento,now );
              
                mostrarMensaje(labels.getString("listadoEventosAdmin.eventoAprobado"));
            } catch (ClaseExcepciones e) {
                mostrarMensaje(labels.getString("listadoEventosAdmin.errorAprobar") + e.getMessage());
            }
        } else {
            mostrarMensaje(labels.getString("listadoEventosAdmin.seleccioneEvento"));
        }
    }

    // Mostrar mensaje en un JOptionPane
    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, labels.getString("listadoEventosAdmin.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
    }
}