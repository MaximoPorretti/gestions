package frontend;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
import backend.accesos.*;
import backend.api.PersistenceApi;
import backend.dto.UsuarioDTO;
import commons.Utils;

public class VentanaPrincipalAdmin extends JFrame {
    private UsuarioDTO usuarioActual;
    private PersistenceApi api;
    private ResourceBundle labels;
    private Utils utils;

    // Paleta de colores verde para la interfaz
    private Color colorFondo = new Color(240, 255, 240);
    private Color colorPrincipal = new Color(46, 139, 87);
    private Color colorSecundario = new Color(60, 179, 113);
    private Color colorTexto = Color.WHITE;

    private JLabel lblTitulo; // Título para actualizar
    private JMenuBar menuBar; // Menú para actualizar

    public VentanaPrincipalAdmin(PersistenceApi api, UsuarioDTO usuarioActual, Utils utils) {
        this.api = api;
        this.usuarioActual = usuarioActual;
        this.utils = utils;

        // Configuración inicial del ResourceBundle
        labels = ResourceBundle.getBundle("labels", utils.obtenerIdiomaActual());

        // Configuración inicial de la ventana
        setTitle(labels.getString("adminWindow.titulo"));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);

        // Configurar la interfaz
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondo);

        // Inicializar la interfaz
        initUI();
    }

    private void initUI() {
        // Título en la parte superior
        JPanel panelTitulo = new JPanel();
        panelTitulo.setBackground(colorPrincipal);
        lblTitulo = new JLabel(labels.getString("adminWindow.titulo"));
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 30));
        lblTitulo.setForeground(colorTexto);
        panelTitulo.add(lblTitulo, BorderLayout.CENTER);
        getContentPane().add(panelTitulo, BorderLayout.NORTH);

        // Barra de menú
        menuBar = crearMenuBar();
        setJMenuBar(menuBar);
    }

    private JMenuBar crearMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(colorSecundario);

        // Menú de usuarios
        JMenu usuarioMenu = new JMenu(labels.getString("adminWindow.usuarios"));
        usuarioMenu.setFont(new Font("Arial", Font.PLAIN, 14));
        menuBar.add(usuarioMenu);

        JMenuItem altaUsuarioMenuItem = new JMenuItem(labels.getString("adminWindow.usuarios.alta"));
        altaUsuarioMenuItem.addActionListener(e -> {
            try {
                new AltaUsuario(api, utils).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        usuarioMenu.add(altaUsuarioMenuItem);

        JMenuItem listadoUsuarioMenuItem = new JMenuItem(labels.getString("adminWindow.usuarios.listado"));
        listadoUsuarioMenuItem.addActionListener(e -> {
            try {
                new ListadoUsuarios(api, utils).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        usuarioMenu.add(listadoUsuarioMenuItem);

        // Menú de eventos
        JMenu mnEventos = new JMenu(labels.getString("adminWindow.eventos"));
        mnEventos.setFont(new Font("Arial", Font.PLAIN, 14));
        menuBar.add(mnEventos);

        JMenuItem listadoEventosMenuItem = new JMenuItem(labels.getString("adminWindow.eventos.listado"));
        listadoEventosMenuItem.addActionListener(e -> {
            try {
                new ListadoEventosAdmin(api, utils).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        mnEventos.add(listadoEventosMenuItem);

        JMenuItem altaEventosMunicipalesMenuItem = new JMenuItem(labels.getString("adminWindow.eventos.municipales.alta"));
        altaEventosMunicipalesMenuItem.addActionListener(e -> {
            try {
                new AltaEventoMunicipal(usuarioActual, api, utils).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        mnEventos.add(altaEventosMunicipalesMenuItem);

        JMenuItem listadoEventosMunicipalesMenuItem = new JMenuItem(labels.getString("adminWindow.eventos.municipales.listado"));
        listadoEventosMunicipalesMenuItem.addActionListener(e -> {
            try {
                new ListadoEventosMunicipales(api, utils).setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        mnEventos.add(listadoEventosMunicipalesMenuItem);

        // Menú de configuración
        JMenu configuracionMenu = new JMenu(labels.getString("adminWindow.configuracion"));
        configuracionMenu.setFont(new Font("Arial", Font.PLAIN, 14));
        menuBar.add(configuracionMenu);

        JMenuItem salirMenuItem = new JMenuItem(labels.getString("adminWindow.configuracion.salir"));
        salirMenuItem.addActionListener(e -> dispose());
        configuracionMenu.add(salirMenuItem);

        JMenuItem pantallaPrincipalMenuItem = new JMenuItem(labels.getString("adminWindow.configuracion.principal"));
        pantallaPrincipalMenuItem.addActionListener(e -> {
            PersistenceApi persistenceAPI = new PersistenceApi(
                new EventoDAOJDBC(), new EventoMunicipalDAOJDBC(),
                new UsuarioDAOJDBC(), new RolDAOJDBC(), new NotificacionDAOJDBC(), new FavoritosDAOJDBC());
            SwingUtilities.invokeLater(() -> {
                VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(persistenceAPI, utils);
                ventanaPrincipal.setVisible(true);
            });
        });
        configuracionMenu.add(pantallaPrincipalMenuItem);

        // Crear JComboBox para cambiar el idioma
        String[] idiomas = {"Español", "Inglés"};
        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        comboBoxIdiomas.setBackground(colorSecundario);
        comboBoxIdiomas.setForeground(colorTexto);
        comboBoxIdiomas.addActionListener(e -> {
            String selectedLanguage = comboBoxIdiomas.getSelectedIndex() == 0 ? "es" : "en";
            setLanguage(selectedLanguage);  // Cambiar el idioma con la lógica modificada
        });

        menuBar.add(comboBoxIdiomas);
        return menuBar;
    }

    private void setLanguage(String language) {
        Locale locale = new Locale(language);

        // Establecer el idioma actual usando Utils
        utils.establecerIdiomaActual(locale);

        // Cargar el ResourceBundle actualizado
        labels = ResourceBundle.getBundle("labels", utils.obtenerIdiomaActual());

        // Actualizar el título de la ventana
        setTitle(labels.getString("adminWindow.titulo"));
        lblTitulo.setText(labels.getString("adminWindow.titulo"));

        // Eliminar todos los componentes de la barra de menú para evitar conflictos
        if (getJMenuBar() != null) {
            JMenuBar currentMenuBar = getJMenuBar();
            currentMenuBar.removeAll();  // Limpia todos los menús existentes
            setJMenuBar(null);          // Desasocia la barra de menú actual
        }

        // Crear y establecer un nuevo menú actualizado
        setJMenuBar(crearMenuBar());

        // Limpiar y reconstruir el contenido principal si es necesario
        getContentPane().removeAll();
        initUI();

        // Refrescar la interfaz gráfica
        getContentPane().revalidate();
        getContentPane().repaint();
    }


}
