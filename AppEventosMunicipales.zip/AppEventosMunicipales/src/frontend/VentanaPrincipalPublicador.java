package frontend;

import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import backend.dto.EventoMunicipalDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import backend.api.PersistenceApi;

public class VentanaPrincipalPublicador extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private UsuarioDTO usuarioActual;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels; // Para los textos en el idioma seleccionado
    private Utils utils;
    
    private Color colorFondo = new Color(240, 255, 240);
    private Color colorPrincipal = new Color(46, 139, 87);
    private Color colorSecundario = new Color(60, 179, 113);
    private Color colorTexto = Color.WHITE;

    public VentanaPrincipalPublicador(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils) {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils = utils;
        
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondo);

        // Inicializar el idioma por defecto (español)
        setLanguage("es");
    }

    private void initUI() {
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorPrincipal);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JToolBar barraHerramientas = new JToolBar();
        barraHerramientas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        barraHerramientas.setFloatable(false);
        barraHerramientas.setOpaque(false);
        barraHerramientas.setBorderPainted(false);

        // Nombres de los elementos del menú (usando labels)
        String[] menuKeys = {
            "publicadorWindow.salir",
            "publicadorWindow.eventoscomunidad",
            "publicadorWindow.crear",
            "publicadorWindow.miseventos",
            "publicadorWindow.notificacion",
            "publicadorWindow.favoritos"
        };

        for (String key : menuKeys) {
            JButton boton = new JButton(labels.getString(key));
            boton.setBackground(colorSecundario);
            boton.setForeground(colorTexto);
            boton.setFocusPainted(false);
            boton.setBorderPainted(false);
            boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
            boton.addActionListener(e -> {
                try {
                    abrirVentana(key);
                } catch (ClaseExcepciones e1) {
                    mostrarExcepcion("error.ventana_abrir");
                    e1.printStackTrace();
                } catch (SQLException e1) {
					
					e1.printStackTrace();
				}
            });
            barraHerramientas.add(boton);
            barraHerramientas.addSeparator(new Dimension(10, 0));
        }

        // Crear JComboBox para cambiar el idioma
        String[] idiomas = {"Español", "Inglés"};
        JComboBox<String> comboBoxIdiomas = new JComboBox<>(idiomas);
        comboBoxIdiomas.setBackground(colorSecundario);
        comboBoxIdiomas.setForeground(new Color(255, 255, 255));
        comboBoxIdiomas.addActionListener(e -> {
            String selectedLanguage = comboBoxIdiomas.getSelectedIndex() == 0 ? "es" : "en";
            setLanguage(selectedLanguage);  // Cambiar el idioma con la lógica modificada
        });

        barraHerramientas.add(comboBoxIdiomas);
        panelSuperior.add(barraHerramientas, BorderLayout.CENTER);
        getContentPane().add(panelSuperior, BorderLayout.NORTH);

        // Crear la tabla y su modelo
        tableModel = new DefaultTableModel(new String[]{
            labels.getString("publicadorWindow.municipalnombre"),
            labels.getString("publicadorWindow.municipaldescripcion"),
            labels.getString("publicadorWindow.municipalubicacion"),
            labels.getString("publicadorWindow.municipalfechahora")
        }, 0);
        table = new JTable(tableModel);
        table.setEnabled(false);
        table.setBackground(new Color(255, 255, 255));
        table.setForeground(new Color(0, 0, 0));
        table.setFont(new Font("MS UI Gothic", Font.BOLD, 10));
        table.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 0)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.SOUTH);

        JLabel lblTitulo = new JLabel(labels.getString("publicadorWindow.titulo"));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setForeground(colorPrincipal);
        lblTitulo.setFont(new Font("Stencil", Font.PLAIN, 50));
        getContentPane().add(lblTitulo, BorderLayout.CENTER);
        
     // verifica si el evento se realiza el dia de hoy y se le notifica
        try {
			persistenceApi.verificarFavoritosHoy(usuarioActual);
		} catch (ClaseExcepciones e1) {
			 mostrarExcepcion("error.ventana_verificar_favorito");
			
		}
        cargarDatos(); // Cargar los datos de eventos municipales
    }

    // Método para cambiar el idioma
    private void setLanguage(String language) {
        Locale locale = new Locale(language);
        // Establecer el idioma actual usando el método del backend
        utils.establecerIdiomaActual(locale);  // Llamada al método establecerIdiomaActual

        // Cargar los recursos del idioma
        labels = ResourceBundle.getBundle("labels", locale);

        // Limpiar la ventana y volver a inicializar la interfaz con el nuevo idioma
        getContentPane().removeAll();
        initUI();
        revalidate();
        repaint();
    }

    private void mostrarExcepcion(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Método que abre diferentes ventanas en función de la opción seleccionada
    private void abrirVentana(String key) throws ClaseExcepciones, SQLException {
        String opcion = labels.getString(key);
        switch (key) {
            case "publicadorWindow.eventoscomunidad":
                new ListadoEventos(usuarioActual, persistenceApi, utils).setVisible(true);
                break;
            case "publicadorWindow.crear":
                new AltaEvento(usuarioActual, persistenceApi, utils).setVisible(true);
                break;
            case "publicadorWindow.miseventos":
                new ListadoMisEventos(usuarioActual, persistenceApi, utils).setVisible(true);
                break;
            case "publicadorWindow.notificacion":
                new ListadoMisNotificaciones(usuarioActual, persistenceApi, utils).setVisible(true);
                break;
            case "publicadorWindow.favoritos":
                new ListadoMisFavoritos(usuarioActual, persistenceApi, utils).setVisible(true);
                break;
            case "publicadorWindow.salir":
                dispose();
                break;
            default:
                JOptionPane.showMessageDialog(this, labels.getString("publicadorWindow.noimplementado") + opcion);
        }
    }

    private void cargarDatos() {
        try {
            List<EventoMunicipalDTO> eventos = persistenceApi.obtenerEventosMunicipales();
            for (EventoMunicipalDTO evento : eventos) {
                tableModel.addRow(new Object[]{
                    evento.getNombre(),
                    evento.getDescripcion(),
                    evento.getUbicacion(),
                    evento.getHorario(),
                });
            }
        } catch (ClaseExcepciones e) {
            mostrarExcepcion("Error al cargar los datos");
            e.printStackTrace();
        }
    }
}
