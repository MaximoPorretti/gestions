package frontend;

import backend.api.PersistenceApi;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.border.LineBorder;

public class ListadoUsuarios extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi; // Usamos la API en lugar de UsuarioDAOJDBC
    private ResourceBundle labels;
    private Utils utils;
    public ListadoUsuarios( PersistenceApi persistenceApi, Utils utils ) {
        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);


        // Configuración de la ventana
        setTitle(labels.getString("ListaUsuarioWindow.sistema"));
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());

        // Crear la tabla y su modelo
        tableModel = new DefaultTableModel(new String[]{
        		labels.getString("ListaUsuarioWindow.usuario"), 
        		labels.getString("ListaUsuarioWindow.nombre"), 
        		labels.getString("ListaUsuarioWindow.correo"), 
        		labels.getString("ListaUsuarioWindow.rol")
        		}, 0);
        table = new JTable(tableModel);
        table.setBorder(new LineBorder(new Color(0, 128, 64)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); 
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Cargar datos en la tabla
        cargarDatos();

        // Panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setForeground(new Color(154, 205, 50));
        buttonPanel.setBorder(new LineBorder(new Color(0, 128, 0), 13));
        JButton btnCerrar = new JButton(labels.getString("ListaUsuarioWindow.cerrar"));
        btnCerrar.addActionListener(e -> dispose());
        buttonPanel.add(btnCerrar);

        // Botón de eliminar
        JButton btnEliminar = new JButton(labels.getString("ListaUsuarioWindow.eliminar"));
        buttonPanel.add(btnEliminar);

        // Acción de eliminar
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener la fila seleccionada
                int selectedRow = table.getSelectedRow();

                if (selectedRow != -1) {  // Verifica si hay una fila seleccionada
                    String usuario = (String) table.getValueAt(selectedRow, 0);  // Obtener el usuario de la primera columna

                    // Eliminar usuario de la base de datos usando la API
                    try {
                        persistenceApi.eliminarUsuario(usuario);
                        // Eliminar usuario de la tabla
                        tableModel.removeRow(selectedRow);
                        JOptionPane.showMessageDialog(null, labels.getString("ListaUsuarioWindow.eliminacionexitosa"));
                    } catch (ClaseExcepciones ex) {
                        JOptionPane.showMessageDialog(null, labels.getString("ListaUsuarioWindow.erroreliminar") + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, labels.getString("ListaUsuarioWindow.eliminarsinselec"));
                }
            }
        });

        // Estilo de la tabla
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        table.setGridColor(new Color(0, 128, 0));

        // Agregar los botones al panel
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
    }

    public void cargarDatos() {
        List<UsuarioDTO> usuarios = null;
        try {
            usuarios = persistenceApi.obtenerUsuarios(); // Usar la API para obtener los usuarios
        } catch (ClaseExcepciones e) {
            JOptionPane.showMessageDialog(null, labels.getString("ListaUsuarioWindow.errorcarga") + e.getMessage());
            e.printStackTrace();
        }

        // Verificar si la lista de usuarios no es null antes de intentar agregar datos a la tabla
        if (usuarios != null) {
            for (UsuarioDTO usuario : usuarios) {
                // Agregar cada usuario al modelo de la tabla
                tableModel.addRow(new Object[]{
                        usuario.getUsuario(),  
                        usuario.getNombre(),
                        usuario.getEmail(),
                        usuario.getRol().getNombre()
                });
            }
        } else {
            JOptionPane.showMessageDialog(null, labels.getString("ListaUsuarioWindow.errorsinusuarios"));
        }
    }


}
