package frontend;

import backend.accesos.EventoDAOJDBC;
import backend.accesos.EventoMunicipalDAOJDBC;
import backend.accesos.FavoritosDAOJDBC;
import backend.accesos.NotificacionDAOJDBC;
import backend.accesos.RolDAOJDBC;
import backend.accesos.UsuarioDAOJDBC;
import backend.api.PersistenceApi;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import java.util.Locale;

public class VentanaInicioSesion extends JFrame {
    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JLabel etiquetaResultado;
    private UsuarioDTO usuarioActual;
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;
    public VentanaInicioSesion( PersistenceApi persistenceApi, Utils utils ) {

        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        
        setTitle(labels.getString("menuInicioSesion.sistema"));
        getContentPane().setBackground(new Color(85, 107, 47));
        setLayout(new GridLayout(0, 2, 10, 10));

        // Componentes de la interfaz
        JLabel labelUsuario = new JLabel(labels.getString("menuInicioSesion.usuario"));
        labelUsuario.setForeground(Color.WHITE);
        campoUsuario = new JTextField(20);

        JLabel labelContrasena = new JLabel(labels.getString("menuInicioSesion.contraseña"));
        labelContrasena.setForeground(Color.WHITE);
        campoContrasena = new JPasswordField(20);
        
        // Casilla para mostrar/ocultar contraseña
        JCheckBox mostrarContrasena = new JCheckBox(labels.getString("menuInicioSesion.mostrarContrasena"));
        mostrarContrasena.setForeground(Color.WHITE);
        mostrarContrasena.setBackground(new Color(85, 107, 47));
        mostrarContrasena.addActionListener(e -> {
            campoContrasena.setEchoChar(mostrarContrasena.isSelected() ? '\u0000' : '*');
        });

        etiquetaResultado = new JLabel("", SwingConstants.CENTER);

        JButton btnVolver = new JButton(labels.getString("menuInicioSesion.volver"));
        btnVolver.setFont(new Font("Tahoma", Font.PLAIN, 17));
        btnVolver.setForeground(new Color(154, 205, 50));
        btnVolver.addActionListener(new VolverListener());

        JButton botonLogin = new JButton(labels.getString("menuInicioSesion.ingresar"));
        botonLogin.setFont(new Font("Tahoma", Font.PLAIN, 17));
        botonLogin.setForeground(new Color(154, 205, 50));
        botonLogin.addActionListener(new LoginListener());

     // Añadir componentes al layout
        add(labelUsuario);
        add(campoUsuario);
        add(labelContrasena);
        add(campoContrasena);
        add(new JLabel()); // Espacio vacío
        add(mostrarContrasena);
        add(etiquetaResultado);
        add(btnVolver);
        add(botonLogin);

        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private class VolverListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new VentanaPrincipal(persistenceApi, utils).setVisible(true);
        }
    }

    private class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String usuario = campoUsuario.getText().trim();
            String contrasena = new String(campoContrasena.getPassword()).trim();

            try {
                if (usuario.isEmpty()) {
                    etiquetaResultado.setText(labels.getString("menuInicioSesion.errorusuario"));
                    etiquetaResultado.setForeground(Color.RED);
                    return;
                }

                usuarioActual = persistenceApi.verificarUsuario(usuario, contrasena);

                if (usuarioActual == null) {
                    etiquetaResultado.setText(labels.getString("menuInicioSesion.errorusuarionoexiste"));
                    etiquetaResultado.setForeground(Color.RED);
                    return;
                }

                etiquetaResultado.setText(labels.getString("menuInicioSesion.mensaje") + usuarioActual.getNombre() + "!");
                etiquetaResultado.setForeground(Color.GREEN);

                // Acciones según el rol del usuario
                switch (usuarioActual.getRol().getNombre()) {
                    case "Publicador" :
                        new VentanaPrincipalPublicador(usuarioActual, persistenceApi, utils).setVisible(true);
                        dispose();
                        break;
                    case "Publicista":
                        new VentanaPublicista(usuarioActual, persistenceApi, utils).setVisible(true);
                        dispose();
                        break;
                    case "Publisher" :
                        new VentanaPrincipalPublicador(usuarioActual, persistenceApi, utils).setVisible(true);
                        dispose();
                        break;
                    case "Advertiser":
                        new VentanaPublicista(usuarioActual, persistenceApi, utils).setVisible(true);
                        dispose();
                        break;
                    case "Administrador":
                        new VentanaPrincipalAdmin(persistenceApi, usuarioActual, utils).setVisible(true);
                        dispose();
                        break;
                    default:
                        etiquetaResultado.setText(labels.getString("menuInicioSesion.rolerror"));
                        etiquetaResultado.setForeground(Color.RED);
                }
            } catch (ClaseExcepciones ex) {
                etiquetaResultado.setText(labels.getString("menuInicioSesion.errorcontraseña"));
                etiquetaResultado.setForeground(Color.RED);
            }
        }
    }


    public static void main(String[] args) {
    	Utils utils= new Utils();
        SwingUtilities.invokeLater(() -> {
            PersistenceApi persistenceAPI = new PersistenceApi(
                new EventoDAOJDBC(),
                new EventoMunicipalDAOJDBC(),
                new UsuarioDAOJDBC(),
                new RolDAOJDBC(),
                new NotificacionDAOJDBC(),
                new FavoritosDAOJDBC()
            );
            try {
				new VentanaInicioSesion(persistenceAPI, utils).setVisible(true);
			} catch (Exception e) {
	
				e.printStackTrace();
			}
        });
    }
}
