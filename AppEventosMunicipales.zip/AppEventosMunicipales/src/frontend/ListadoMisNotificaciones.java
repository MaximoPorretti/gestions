package frontend;

import backend.api.PersistenceApi;
import backend.dto.NotificacionDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class ListadoMisNotificaciones extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private PersistenceApi persistenceApi;
    private UsuarioDTO usuarioActual;
    private ResourceBundle labels;
    private Utils utils;
    public ListadoMisNotificaciones(UsuarioDTO usuarioActual, PersistenceApi persistenceApi, Utils utils ) throws ClaseExcepciones {
        this.usuarioActual = usuarioActual;
        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        configurarVentana();
        configurarTabla();
        cargarDatos();
        agregarPanelBotones();
    }

    private void configurarVentana() {
        setTitle(labels.getString("listadoMisNotificaciones.titulo"));
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
    }

    private void configurarTabla() {
        tableModel = new DefaultTableModel(new String[]{
                labels.getString("listadoMisNotificaciones.column.id"),
                labels.getString("listadoMisNotificaciones.column.mensaje"),
                labels.getString("listadoMisNotificaciones.column.fechaHora")
        }, 0);

        table = new JTable(tableModel);
        table.setBorder(new LineBorder(new Color(0, 128, 64)));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.setShowGrid(true);
        table.setGridColor(new Color(0, 128, 0));

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void agregarPanelBotones() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new LineBorder(new Color(0, 128, 0), 13));

        JButton btnCerrar = new JButton(labels.getString("listadoMisNotificaciones.btnCerrar"));
        btnCerrar.addActionListener(e -> dispose());
        buttonPanel.add(btnCerrar);

        JButton btnEliminar = new JButton(labels.getString("listadoMisNotificaciones.btnEliminar"));
        btnEliminar.addActionListener(e -> eliminarNotificacion());
        buttonPanel.add(btnEliminar);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void cargarDatos() throws ClaseExcepciones {
        List<NotificacionDTO> notificaciones = persistenceApi.MisNotificaciones(usuarioActual);

		if (notificaciones == null || notificaciones.isEmpty()) {
		    JOptionPane.showMessageDialog(this, labels.getString("listadoMisNotificaciones.noNotificaciones"),
		            labels.getString("listadoMisNotificaciones.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
		    return;
		}

		DateTimeFormatter formatterEntrada = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		DateTimeFormatter formatterSalida = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

		for (NotificacionDTO notificacion : notificaciones) {
		    
		    
		    tableModel.addRow(new Object[]{
		            notificacion.getId(),
		            notificacion.getMensaje(),
		           notificacion.getFechaCreacion()
		    });
		}

		ajustarColumnas();
    }

    private void ajustarColumnas() {
        table.getColumnModel().getColumn(0).setPreferredWidth(100); // ID
        table.getColumnModel().getColumn(1).setPreferredWidth(400); // Mensaje
        table.getColumnModel().getColumn(2).setPreferredWidth(150); // Fecha y Hora

        // Ocultar columna del ID
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
    }

    private void eliminarNotificacion() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, labels.getString("listadoMisNotificaciones.seleccioneNotificacion"),
                    labels.getString("listadoMisNotificaciones.dialogTitle"), JOptionPane.WARNING_MESSAGE);
            return;
        }

        long idNotificacion = (Long) table.getValueAt(selectedRow, 0);

        try {
            persistenceApi.eliminarNotificacion(idNotificacion);
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(this, labels.getString("listadoMisNotificaciones.notificacionEliminada"),
                    labels.getString("listadoMisNotificaciones.dialogTitle"), JOptionPane.INFORMATION_MESSAGE);
        } catch (ClaseExcepciones ex) {
            JOptionPane.showMessageDialog(this, labels.getString("listadoMisNotificaciones.errorEliminar") + ex.getMessage(),
                    labels.getString("listadoMisNotificaciones.dialogTitle"), JOptionPane.ERROR_MESSAGE);
        }
    }
}