package frontend;

import javax.swing.*;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import java.util.ResourceBundle;
import backend.api.PersistenceApi;
import backend.dto.NotificacionDTO;
import backend.dto.RolDTO;
import backend.dto.UsuarioDTO;
import commons.Utils;
import commons.exepciones.ClaseExcepciones;
import java.awt.Color;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class AltaUsuario extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JTextField txtNombre;
    private JTextField txtEmail;
    private JComboBox<String> comboBoxRoles; 
    private PersistenceApi persistenceApi;
    private ResourceBundle labels;
    private Utils utils;
    public AltaUsuario( PersistenceApi persistenceApi, Utils utils ) {

        this.persistenceApi = persistenceApi;
        this.utils= utils;
        
        // Obtener el idioma actual desde PersistenceApi
        Locale idiomaActual = utils.obtenerIdiomaActual();
        // Cargar los labels en el idioma actual
        this.labels = ResourceBundle.getBundle("labels", idiomaActual);

        getContentPane().setBackground(new Color(102, 153, 51));
        initialize();
    }

    private void initialize() {
        setTitle(labels.getString("menuAltaUsuario.sistema"));
        setSize(508, 340);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        getContentPane().add(crearLabel(labels.getString("menuAltaUsuario.usuario"), 30, 30, 80, 25));
        txtUsuario = crearCampoTexto(171, 30, 200, 25);
        getContentPane().add(txtUsuario);

        getContentPane().add(crearLabel(labels.getString("menuAltaUsuario.contraseña"), 30, 70, 80, 25));
        txtContrasena = new JPasswordField();
        txtContrasena.setBounds(171, 70, 200, 25);
        getContentPane().add(txtContrasena);

        getContentPane().add(crearLabel(labels.getString("menuAltaUsuario.nombreapellido"), 30, 110, 131, 25));
        txtNombre = crearCampoTexto(171, 110, 200, 25);
        getContentPane().add(txtNombre);

        getContentPane().add(crearLabel(labels.getString("menuAltaUsuario.correo"), 30, 150, 131, 25));
        txtEmail = crearCampoTexto(171, 150, 200, 25);
        getContentPane().add(txtEmail);

        getContentPane().add(crearLabel(labels.getString("menuAltaUsuario.rol"), 30, 190, 80, 25));
        comboBoxRoles = new JComboBox<>(new String[]{
            labels.getString("menuAltaUsuario.publicista"),
            labels.getString("menuAltaUsuario.publicador")
        });
        comboBoxRoles.setBounds(171, 190, 200, 25);
        comboBoxRoles.setForeground(new Color(51, 102, 0));
        getContentPane().add(comboBoxRoles);

        JButton btnRegistrar = new JButton(labels.getString("menuAltaUsuario.registrar"));
        btnRegistrar.setBounds(252, 230, 100, 25);
        btnRegistrar.setForeground(new Color(51, 102, 51));
        btnRegistrar.addActionListener(e -> registrarUsuario());
        getContentPane().add(btnRegistrar);

        JButton btnCerrar = new JButton(labels.getString("menuAltaUsuario.cerrar"));
        btnCerrar.setBounds(142, 230, 100, 25);
        btnCerrar.setForeground(new Color(51, 102, 51));
        btnCerrar.addActionListener(e -> cerrarVentana());
        getContentPane().add(btnCerrar);
    }

    private JLabel crearLabel(String texto, int x, int y, int ancho, int alto) {
        JLabel label = new JLabel(texto);
        label.setForeground(Color.WHITE);
        label.setBounds(x, y, ancho, alto);
        return label;
    }

    private JTextField crearCampoTexto(int x, int y, int ancho, int alto) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, ancho, alto);
        return textField;
    }

    private void registrarUsuario() {
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            private boolean success = false;

            @Override
            protected Void doInBackground() {
                try {
                    String usuario = validarCampo(txtUsuario.getText(), labels.getString("menuAltaUsuario.errorusuariovacio"));
                    String contrasena = validarCampo(new String(txtContrasena.getPassword()), labels.getString("menuAltaUsuario.errorcontraseñavacia"));
                    String nombre = validarCampo(txtNombre.getText(), labels.getString("menuAltaUsuario.errornombreapellidovacio"));
                    String email = validarCampo(txtEmail.getText(), labels.getString("menuAltaUsuario.errorcorreovacio"));
                    String rol = validarCampo((String) comboBoxRoles.getSelectedItem(), labels.getString("menuAltaUsuario.errorrolvacio"));

                    persistenceApi.registrarUsuario(usuario, contrasena, email, nombre, rol);
                    Random random = new Random();
                    long randomInt = random.nextInt(100);
                    LocalDateTime now = LocalDateTime.now();
                    RolDTO rolDto = new RolDTO(rol);
                    UsuarioDTO usuarioDto = new UsuarioDTO(usuario, contrasena, email, rolDto);
                    NotificacionDTO notificacionDto = new NotificacionDTO(randomInt,labels.getString("menuAltaUsuario.mensaje"),now, usuarioDto);
                    persistenceApi.nuevaNotificacion(labels.getString("menuAltaUsuario.mensaje"), usuarioDto.getUsuario(),now);
                    success = true;
                } catch (IllegalArgumentException | ClaseExcepciones ex) {
                    mostrarMensajeError(ex.getMessage());
                }
                return null;
            }

            @Override
            protected void done() {
                if (success) {
                    JOptionPane.showMessageDialog(null, labels.getString("menuAltaUsuario.crear"));
                    dispose();
                }
            }
        };
        worker.execute();
    }

    private String validarCampo(String valor, String mensajeError) {
        return Optional.ofNullable(valor).filter(v -> !v.isEmpty()).orElseThrow(() -> new IllegalArgumentException(mensajeError));
    }

    private void mostrarMensajeError(String mensaje) {
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, mensaje));
    }

    private void cerrarVentana() {
        int confirm = JOptionPane.showConfirmDialog(null, labels.getString("menuAltaUsuario.mensajecerrar"), labels.getString("menuAltaUsuario.mensajeconfirmacion"), JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
        }
    }
}