package commons;

import java.util.Locale;
import java.util.ResourceBundle;

public class Utils {

    private Locale idiomaActual = Locale.getDefault();
    private ResourceBundle resourceBundle;

    public Utils() {
        cargarResourceBundle();
    }

    public void establecerIdiomaActual(Locale locale) {
        if (locale == null) {
            throw new IllegalArgumentException(obtenerMensaje("exc.error_locale_null"));
        }
        this.idiomaActual = locale;
        cargarResourceBundle();
    }

    public Locale obtenerIdiomaActual() {
        return idiomaActual;
    }

    private void cargarResourceBundle() {
        try {
            resourceBundle = ResourceBundle.getBundle("labels", idiomaActual);
        } catch (Exception e) {
            throw new RuntimeException(
                obtenerMensaje("exc.error_cargar_idiomaActual").replace("{0}", idiomaActual.toString()),
                e
            );
        }
    }

    public String obtenerMensaje(String clave) {
        try {
            return resourceBundle.getString(clave);
        } catch (Exception e) {
            return "[" + clave + "] " + 
                obtenerMensaje("exc.error_mensaje_no_encontrado").replace("{0}", clave);
        }
    }
}