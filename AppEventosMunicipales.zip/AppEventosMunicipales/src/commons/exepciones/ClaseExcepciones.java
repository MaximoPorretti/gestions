package commons.exepciones;

import java.util.Locale;
import java.util.ResourceBundle;

public class ClaseExcepciones extends Exception {

    private static final long serialVersionUID = -2617559121301244825L;

    public ClaseExcepciones() {
        super(getMessage("exc.error_general"));
    }

    public ClaseExcepciones(String key) {
        super(getMessage(key));
    }

    public ClaseExcepciones(String key, Throwable cause) {
        super(getMessage(key), cause);
    }

    private static String getMessage(String key) {
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("labels", Locale.getDefault());
            return bundle.getString(key);
        } catch (Exception e) {
            try {
                ResourceBundle bundle = ResourceBundle.getBundle("labels", Locale.getDefault());
                return bundle.getString("exc.error_desconocido") + " [" + key + "]";
            } catch (Exception fallbackException) {
                return "[" + key + "]";
            }
        }
    }
}
