package backend.api;

import backend.dto.*;
import backend.accesos.*;
import commons.exepciones.ClaseExcepciones;

import entities.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class PersistenceApi implements IApi {

    private final EventoDAO eventoDao;
    private final EventoMunicipalDAO eventoMunicipalDao;
    private final UsuarioDAO usuarioDao;
    private final RolDAO rolDao;
    private final NotificacionDAO notificacionDao;
    private final FavoritosDAO favoritoDao;
    private UsuarioDTO usuarioActual;

    public PersistenceApi(EventoDAO eventoDao, EventoMunicipalDAO eventoMunicipalDao, UsuarioDAO usuarioDao,
                          RolDAO rolDao, NotificacionDAO notificacionDao, FavoritosDAO favoritoDao) {
        this.eventoDao = eventoDao;
        this.eventoMunicipalDao = eventoMunicipalDao;
        this.usuarioDao = usuarioDao;
        this.rolDao = rolDao;
        this.notificacionDao = notificacionDao;
        this.favoritoDao = favoritoDao;
    }

    // Gestión de usuarios
    
    @Override
    public void actualizarEstado(String nombre, String nuevoEstado) throws ClaseExcepciones {
        eventoDao.updateEstado(nombre, nuevoEstado);
    }

    @Override
    public void registrarUsuario(String username, String password, String email, String nombre, String rol) throws ClaseExcepciones {
        Rol rolUsuario = new Rol(rol);
        Usuario usuario = new Usuario(username, password, nombre, email, rolUsuario);
        rolDao.create(rolUsuario, username);
        usuarioDao.create(usuario);
    }

    @Override
    public void eliminarUsuario(String username) throws ClaseExcepciones {
        usuarioDao.remove(username);
    }

    @Override
    public UsuarioDTO obtenerUsuarioDTO(Usuario username) throws ClaseExcepciones {
        Usuario usuario = usuarioDao.find(username.getUsuario());
        if (usuario == null) {
            throw new ClaseExcepciones("Usuario no encontrado: " + username);
        }
        return new UsuarioDTO(usuario.getUsuario(), usuario.getNombre(), usuario.getEmail(), new RolDTO(usuario.getRol().getNombre()));
    }

    @Override
    public List<UsuarioDTO> obtenerUsuarios() throws ClaseExcepciones {
        return usuarioDao.findAll().stream()
                .map(usuario -> {
                    try {
                        return new UsuarioDTO(usuario.getUsuario(), usuario.getNombre(), usuario.getEmail(), new RolDTO(usuario.getRol().getNombre()));
                    } catch (ClaseExcepciones e) {
                        e.printStackTrace();
                    }
                    return usuarioActual;
                })
                .collect(Collectors.toList());
    }

    @Override
    public UsuarioDTO verificarUsuario(String username, String contrasena) throws ClaseExcepciones {
        Usuario usuario = usuarioDao.find(username);
        if (usuario == null || !usuario.getContrasena().equals(contrasena)) {
            throw new ClaseExcepciones("Credenciales inválidas.");
        }
        return new UsuarioDTO(usuario.getUsuario(), usuario.getNombre(), usuario.getEmail(), new RolDTO(usuario.getRol().getNombre()));
    }
	public Usuario obtenerUsuarioPorUsername(String nombre) {
		Usuario usuario;
		try {
			usuario = usuarioDao.find(nombre);
		} catch (ClaseExcepciones e) {   
			throw new RuntimeException("Error al obtener información del usuario: " + e.getMessage(), e);
		}
		return usuario;
	}
    @Override
    public UsuarioDTO obtenerUsuarioActual() {
        return usuarioActual;
    }

    // Gestión de eventos
   
	@Override
    public List<EventoDTO> obtenerEventosDelUsuario(UsuarioDTO usuario)throws ClaseExcepciones {
    	Rol rol =new Rol(usuario.getRol().getNombre());
    	Usuario usuario1= usuarioDao.find(usuario.getUsuario());
    	Usuario usuarioEventos = new Usuario(usuario1.getUsuario(), usuario1.getContrasena(),usuario1.getNombre(),usuario1.getEmail(),rol);
    	  List<Evento> evento = eventoDao.findByUsuario(usuarioEventos);
    	  List<EventoDTO> eventosDTO = new ArrayList<>();
    	  for (Evento e : evento) {
    	      eventosDTO.add(new EventoDTO(
    	          e.getNombre(),
    	          e.getUbicacion(),
    	          e.getDescripcion(),
    	          e.getEtiqueta(),
    	          e.getHorario(),
    	          usuario,
    	          e.getEstado()
    	      ));
    	  }
    	  return eventosDTO;
      }
	
    	
    
    @Override
    public void registrarEvento(EventoDTO eventoDTO) throws ClaseExcepciones {
    	Rol rol=new Rol(eventoDTO.getUsuario().getRol().getNombre());
    	Usuario usuario = new Usuario(
    		    eventoDTO.getUsuario().getUsuario(),
    		    eventoDTO.getUsuario().getNombre(),
    		    eventoDTO.getUsuario().getEmail(),
    		    " a",
    		    rol
    		);
        Evento evento = new Evento(
                eventoDTO.getNombre(),
                eventoDTO.getUbicacion(),
                eventoDTO.getDescripcion(),
                eventoDTO.getEtiqueta(),
                usuario,
                eventoDTO.getHorario(),
                eventoDTO.getEstado()
        );
        eventoDao.create(evento);
    }

    @Override
    public void actualizarEvento(EventoDTO eventoDTO) throws ClaseExcepciones {
    	Rol rol=new Rol(eventoDTO.getUsuario().getRol().getNombre());
    	Usuario usuario1= usuarioDao.find(eventoDTO.getUsuario().getUsuario());
    	Usuario usuario = new Usuario(
    		    eventoDTO.getUsuario().getUsuario(),
    		    eventoDTO.getUsuario().getNombre(),
    		    eventoDTO.getUsuario().getEmail(),
    		    usuario1.getContrasena(),
    		    rol
    		);
        Evento evento = new Evento(
                eventoDTO.getNombre(),
                eventoDTO.getUbicacion(),
                eventoDTO.getDescripcion(),
                eventoDTO.getEtiqueta(),
                usuario,
                eventoDTO.getHorario(),
                eventoDTO.getEstado()
        );
        eventoDao.update(evento);
    }

    @Override
    public List<EventoDTO> obtenerEventos() throws ClaseExcepciones {
        return eventoDao.findAll().stream()
                .map(eventoInfo -> {
                    try {
                        // Desestructurar la información del evento obtenida
                        String[] eventoParts = eventoInfo.split(", ");
                        String nombre = eventoParts[0].split(": ")[1];
                        String ubicacion = eventoParts[1].split(": ")[1];
                        String descripcion = eventoParts[2].split(": ")[1];
                        String horarioStr = eventoParts[3].split(": ")[1];
                        String estado = eventoParts[4].split(": ")[1];
                        String etiqueta = eventoParts[5].split(": ")[1];
                        String usuarioNombre = eventoParts[6].split(": ")[1];

                        // Validar que los campos clave no estén vacíos
                        if (nombre.isEmpty() || ubicacion.isEmpty() || descripcion.isEmpty() || horarioStr.isEmpty() || estado.isEmpty()) {
                            throw new ClaseExcepciones("Evento con datos incompletos: " + eventoInfo);
                        }

                        // Validar formato de la fecha
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime horario;
                        try {
                            horario = LocalDateTime.parse(horarioStr, formatter);
                        } catch (DateTimeParseException e) {
                            throw new ClaseExcepciones("Formato de fecha inválido para el evento: " + eventoInfo, e);
                        }

                     // Validar estado
                        if (!estado.equals("Aprobado") && !estado.equals("pendiente") && !estado.equals("Approved") && !estado.equals("pending"))  {
                            throw new ClaseExcepciones("Estado inválido para el evento: " + eventoInfo);
                        }


                        // Obtener UsuarioDTO
                        Usuario usuarioEntidad = obtenerUsuarioPorUsername(usuarioNombre);
                        UsuarioDTO usuarioDTO = obtenerUsuarioDTO(usuarioEntidad);

                        // Crear el EventoDTO con los datos extraídos
                        EventoDTO eventoDTO = new EventoDTO(nombre, ubicacion, descripcion, etiqueta, horario, usuarioDTO, estado);

                        return eventoDTO;
                    
                    } catch (Exception e) {
                        throw new RuntimeException("Error al procesar el evento: " + eventoInfo, e);
                    }
                })
                .collect(Collectors.toList());
    }


    // Gestión de eventos municipales
    @Override
    public void registrarEventoMunicipal(EventoMunicipalDTO eventoMunicipalDTO) throws ClaseExcepciones {
        EventoMunicipal evento = new EventoMunicipal(
                eventoMunicipalDTO.getNombre(),
                eventoMunicipalDTO.getUbicacion(),
                eventoMunicipalDTO.getDescripcion(),
                eventoMunicipalDTO.getHorario()
        );
        eventoMunicipalDao.create(evento);
    }

    @Override
    public void actualizarEventoMunicipal(EventoMunicipalDTO eventoMunicipalDTO) throws ClaseExcepciones {
        EventoMunicipal evento = new EventoMunicipal(
                eventoMunicipalDTO.getNombre(),
                eventoMunicipalDTO.getUbicacion(),
                eventoMunicipalDTO.getDescripcion(),
                eventoMunicipalDTO.getHorario()
        );
        eventoMunicipalDao.update(evento);
    }

    @Override
    public void eliminarEventoMunicipal(String nombre) throws ClaseExcepciones {
        eventoMunicipalDao.remove(nombre);
    }

    @Override
    public List<EventoMunicipalDTO> obtenerEventosMunicipales() throws ClaseExcepciones {
        return eventoMunicipalDao.findAll().stream()
                .map(eventoInfo -> {
                    try {
                        // Separamos los datos de la cadena
                        String[] eventoParts = eventoInfo.split(", ");
                        String nombre = eventoParts[0].split(": ")[1];
                        String ubicacion = eventoParts[1].split(": ")[1];
                        String descripcion = eventoParts[2].split(": ")[1];
                        String horarioStr = eventoParts[3].split(": ")[1];
                        
                        // Convertimos la cadena 'horario' a LocalDateTime con el formato sin segundos
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime horario = LocalDateTime.parse(horarioStr, formatter);

                        // Crear el EventoDTO con los datos extraídos
                        EventoMunicipalDTO eventoMunicipalDTO = new EventoMunicipalDTO(nombre, ubicacion, descripcion, horario);

                        return eventoMunicipalDTO;
                    } catch (Exception e) {
                        throw new RuntimeException("Error al procesar los eventos", e);
                    }
                })
                .collect(Collectors.toList());
    }


    // Métodos de Notificaciones



    @Override
    public void eliminarNotificacion( long idNotificacion) throws  ClaseExcepciones {
        try {
           notificacionDao.remove( idNotificacion);
        } catch (ClaseExcepciones e) {
            throw new ClaseExcepciones("Error al eliminar la notificación con ID: " + idNotificacion, e);
        }
    }

    // Método MisNotificaciones
  @Override
    public List<NotificacionDTO> MisNotificaciones(UsuarioDTO usuario) throws ClaseExcepciones {
        // Obtenemos el usuario a partir del username
       Usuario usuario1 =obtenerUsuarioPorUsername(usuario.getUsuario());
        List<Notificacion> notificaciones = notificacionDao.findByUsuario(usuario1);
      
        // Convertimos las notificaciones a DTOs
        return notificaciones.stream()
            .map(n -> {
                LocalDateTime fechaHora = n.getFechaCreacion();  // La fecha ya es un String, no convertimos a LocalDateTime
                try {
					return new NotificacionDTO(n.getId(), n.getMensaje(), fechaHora, usuario);
				} catch (ClaseExcepciones e) {
					// TODO Bloque catch generado automáticamente
					e.printStackTrace();
				}
				return null;
            })
            .collect(Collectors.toList());
    }



    @Override
    public void verificarFavoritosHoy(UsuarioDTO usuario) throws ClaseExcepciones {
        try {
            // Obtenemos el usuario
            Usuario usuario1 = usuarioDao.find(usuario.getUsuario());

            // Obtenemos los favoritos del usuario
            List<EventoDTO> eventosFavoritos = verificadorDeEventosFavoritos(usuario);

            // Iteramos por los eventos favoritos
            for (EventoDTO favorito : eventosFavoritos) {
                LocalDateTime horarioEvento = favorito.getHorario(); // Obtenemos el horario directamente como LocalDateTime

                LocalDate fechaEvento = horarioEvento.toLocalDate();
                LocalTime horaEvento = horarioEvento.toLocalTime();

                // Verificamos si el evento es hoy o ayer
                boolean esHoy = fechaEvento.isEqual(LocalDate.now());
                boolean esAyer = fechaEvento.isEqual(LocalDate.now().minusDays(1)); // Resta un día a la fecha actual

                if ((esHoy && LocalTime.now().isBefore(horaEvento)) || esAyer) {
                    // Creamos el mensaje de notificación
                    String mensaje = "¡¡Su evento favorito \"" + favorito.getNombre() + "\" se realizará el día de hoy " + horarioEvento + "!!";

                    // Verificamos si ya se notificó
                    if (!yaSeNotifico(usuario, favorito.getNombre(), horarioEvento.toLocalDate())) {
                        // Si no se notificó, creamos una nueva notificación
                        nuevaNotificacion(mensaje, usuario.getUsuario(), horarioEvento);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error al procesar las notificaciones para el usuario: " + usuario.getUsuario());
            e.printStackTrace();
        }
    }


 // Método nuevaNotificacion
    @Override
    public void nuevaNotificacion(String nuevoMensaje, String usuario, LocalDateTime fechaNotificacion) throws ClaseExcepciones {
        // Buscar el usuario en la base de datos
        Usuario usuario1 = usuarioDao.find(usuario);

        // Generar un ID aleatorio
        Random random = new Random();
        int id = random.nextInt(100);

        try {
            // Crear la nueva notificación usando LocalDateTime directamente
            Notificacion nuevaNotificacion = new Notificacion(id, nuevoMensaje, fechaNotificacion, usuario1);
            
            // Guardar la notificación en la base de datos a través del DAO
            notificacionDao.create(nuevaNotificacion);

            // Aquí, en lugar de manejarlo como String, guardas el objeto en la base de datos.
        } catch (ClaseExcepciones e) {
            throw new ClaseExcepciones("Error al crear el mensaje", e);
        }
    }

    // Método agregarFavorito
    @Override
    public void agregarFavorito(String usuario, String nombreEvento) throws ClaseExcepciones {
        try {
            Usuario usuario1 = usuarioDao.find(usuario);
            Evento evento1 = eventoDao.find(nombreEvento,usuario1);
            // Creamos un nuevo favorito
            Favorito nuevoFavorito = new Favorito(usuario1, evento1);
            // Lo agregamos a la base de datos a través del DAO
            favoritoDao.createFavorito(nuevoFavorito);
        } catch (ClaseExcepciones e) {
            throw new ClaseExcepciones("Error al agregarlo a favoritos", e);
        }
    }

    // Método eliminarFavorito
    @Override
    public void eliminarFavorito(String usuario, String nombreEvento) throws ClaseExcepciones {
        try {
            // Usamos el DAO para eliminar el favorito
            favoritoDao.eliminarFavorito(usuario, nombreEvento);
        } catch (ClaseExcepciones e) {
            throw new ClaseExcepciones("Error al eliminar de favoritos", e);
        }
    }
 // Método nuevaNotificacion
   


    // Método MisFavoritos
    @Override
    public List<EventoDTO> MisFavoritos(UsuarioDTO usuario) throws  ClaseExcepciones{
        return verificadorDeEventosFavoritos(usuario);
    }

    // Método yaSeNotifico
    @Override
    public boolean yaSeNotifico(UsuarioDTO usuario, String evento, LocalDate fechaEvento) throws ClaseExcepciones {
    	
        List<NotificacionDTO> notificaciones = MisNotificaciones(usuario);

        for (NotificacionDTO notificacion : notificaciones) {
            // Verificamos si ya se notificó el evento
            if (notificacion.getMensaje().equals("¡¡Su evento favorito \"" + evento + "\" se realizará el día de hoy " + fechaEvento + "!!")) {
                return true; // Ya se notificó
            }
        }
        return false; // No se ha notificadobp
    }

    // Método yaEstaEnFavoritos
    @Override
    public Boolean yaEstaEnFavoritos(UsuarioDTO usuarioActual, String nombreEvento) throws ClaseExcepciones {
        // Obtenemos los favoritos del usuario
        List<EventoDTO> favoritos = MisFavoritos(usuarioActual);

        for (EventoDTO favorito : favoritos) {
            // Verificamos si el evento ya está en favoritos
            if (favorito.getNombre().equals(nombreEvento)) {
                return true;
            }
        }
        return false; // No está en favoritos
    }

    // Método eliminarDeMisFavoritos
    @Override
    public void eliminarDeMisFavoritos(String evento) throws ClaseExcepciones {
        // Obtenemos todos los favoritos
        List<Favorito> favoritos = favoritoDao.todosLosFavoritos();
        try {
            for (Favorito favorito : favoritos) {
                if (favorito.getEvento().getNombre().equals(evento)) {
                    LocalDateTime now = LocalDateTime.now();
                    // Notificamos al usuario que el evento fue eliminado
                    nuevaNotificacion("El evento: \"" + evento + "\" ha dejado de existir y de estar en sus favoritos", favorito.getUsuario().getUsuario(), now);

                    // Usamos el DAO para eliminar el favorito
                    favoritoDao.eliminarFavorito(favorito.getUsuario().getUsuario(), evento);
                }
            }
        } catch (ClaseExcepciones e) {
            throw new ClaseExcepciones("Error al eliminar de favoritos", e);
        }
    }

    // Método verificadorDeEventosFavoritos
    @Override
    public List<EventoDTO> verificadorDeEventosFavoritos(UsuarioDTO usuario) throws ClaseExcepciones {
    	 Usuario usuario1 =obtenerUsuarioPorUsername(usuario.getUsuario());
    	// Lista para almacenar los eventos favoritos del usuario
        List<EventoDTO> eventosFavoritos = new ArrayList<>();

        // Obtiene todos los favoritos de la base de datos
    
		List<Favorito> favoritos = favoritoDao.todosLosFavoritos();

        // Recorre la lista de favoritos
        for (Favorito misFavoritos : favoritos) {
            // Verifica si el favorito pertenece al usuario especificado
            if (misFavoritos.getUsuario().getUsuario().equals(usuario.getUsuario())) {
                // Busca el evento por su nombre
                Evento evento = eventoDao.find(misFavoritos.getEvento().getNombre(),usuario1);
                UsuarioDTO usuarioDto = obtenerUsuarioDTO(evento.getUsuario());
                // Añade el evento a la lista de eventos favoritos
                if (evento != null) {
                    eventosFavoritos.add(new EventoDTO(
                    		evento.getNombre(),
                        evento.getUbicacion(),
                        evento.getDescripcion(),
                        evento.getEtiqueta(),
                        evento.getHorario(),
                        usuarioDto,
                        "Aprobado"
                    ));
                }
            }
        }

        // Retorna la lista de eventos favoritos del usuario
        return eventosFavoritos;
    }

	@Override
	public void eliminarEvento(String nombre) throws ClaseExcepciones {
		eventoDao.remove(nombre);
		
	}
}