package backend.api;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import backend.dto.*;
import commons.exepciones.ClaseExcepciones;
import entities.Usuario;

public interface IApi {

    // Gestión de usuarios
    void actualizarEstado(String nombre, String nuevoEstado) throws ClaseExcepciones;

    void registrarUsuario(String username, String password, String email, String nombre, String rol) throws ClaseExcepciones;

    void eliminarUsuario(String username) throws ClaseExcepciones;

    UsuarioDTO obtenerUsuarioDTO(Usuario username) throws ClaseExcepciones;


    List<UsuarioDTO> obtenerUsuarios() throws ClaseExcepciones;

    UsuarioDTO verificarUsuario(String username, String contrasena) throws ClaseExcepciones;

    UsuarioDTO obtenerUsuarioActual() throws ClaseExcepciones;	
    
    // Gestión de eventos
    void registrarEvento(EventoDTO eventoDTO) throws ClaseExcepciones;

    void actualizarEvento(EventoDTO eventoDTO) throws ClaseExcepciones;

    void eliminarEvento(String nombre) throws ClaseExcepciones;

    List<EventoDTO> obtenerEventos() throws ClaseExcepciones;
    
   	List<EventoDTO> obtenerEventosDelUsuario(UsuarioDTO usuario) throws ClaseExcepciones;
    

    // Gestión de eventos municipales
    void registrarEventoMunicipal(EventoMunicipalDTO eventoMunicipalDTO) throws ClaseExcepciones;

    void actualizarEventoMunicipal(EventoMunicipalDTO eventoMunicipalDTO) throws ClaseExcepciones;

    void eliminarEventoMunicipal(String nombre) throws ClaseExcepciones;

    List<EventoMunicipalDTO> obtenerEventosMunicipales() throws ClaseExcepciones;

    // Gestión de notificaciones
    void eliminarNotificacion(long idNotificacion) throws ClaseExcepciones;


    
    void nuevaNotificacion(String nuevoMensaje, String usuario, LocalDateTime fechaNotificacion) throws ClaseExcepciones;
    
	List<NotificacionDTO> MisNotificaciones(UsuarioDTO usuario) throws ClaseExcepciones;
    /* 
	//Método para verificar si ya se notificó el evento
    boolean yaSeNotifico(String usuario, String evento, LocalDate fechaEvento)throws ClaseExcepciones;
	*/
    
    // Gestión de favoritos
 

    void agregarFavorito(String usuario, String nombreEvento) throws ClaseExcepciones;
  
	void verificarFavoritosHoy(UsuarioDTO usuario) throws  ClaseExcepciones;

	boolean yaSeNotifico(UsuarioDTO usuario, String evento, LocalDate fechaEvento) throws ClaseExcepciones;

	Boolean yaEstaEnFavoritos(UsuarioDTO usuarioActual, String nombreEvento) throws ClaseExcepciones;

	void eliminarDeMisFavoritos(String evento) throws ClaseExcepciones;

	void eliminarFavorito(String usuario, String nombreEvento) throws ClaseExcepciones;

	List<EventoDTO> verificadorDeEventosFavoritos(UsuarioDTO usuario) throws ClaseExcepciones;

	List<EventoDTO> MisFavoritos(UsuarioDTO usuario) throws ClaseExcepciones;

	





	

}
