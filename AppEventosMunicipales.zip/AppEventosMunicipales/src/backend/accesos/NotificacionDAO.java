package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Notificacion;
import entities.Usuario;

import java.util.List;

public interface NotificacionDAO {
    void create(Notificacion notificacion) throws ClaseExcepciones;

    void update(Notificacion notificacion) throws ClaseExcepciones;

    Notificacion find(Long id) throws ClaseExcepciones;

    List<Notificacion> findAll() throws ClaseExcepciones;

	void remove(Long id) throws ClaseExcepciones;

	List<Notificacion> findByUsuario(Usuario usuario1) throws ClaseExcepciones;

}