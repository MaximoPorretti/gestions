package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.EventoMunicipal;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;



public class EventoMunicipalDAOJDBC implements EventoMunicipalDAO {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final ZoneId ZONA_LOCAL = ZoneId.of("America/Argentina/Buenos_Aires"); // Ajuste de zona horaria

    @Override
    public void create(EventoMunicipal evento) throws ClaseExcepciones {
        String sql = "INSERT INTO municipales (nombre, ubicacion, descripcion, horario) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, evento.getNombre());
            statement.setString(2, evento.getUbicacion());
            statement.setString(3, evento.getDescripcion());
            // Convertir LocalDateTime a Timestamp con zona horaria ajustada
            statement.setTimestamp(4, Timestamp.valueOf(evento.getHorario().atZone(ZONA_LOCAL).toLocalDateTime()));

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.eventomunicipal_crear " + e.getMessage(), e);
        }
    }

    @Override
    public void update(EventoMunicipal evento) throws ClaseExcepciones {
        String sql = "UPDATE municipales SET ubicacion = ?, descripcion = ?, horario = ? WHERE nombre = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, evento.getUbicacion());
            statement.setString(2, evento.getDescripcion());
            // Convertir LocalDateTime a Timestamp con zona horaria
            statement.setTimestamp(3, Timestamp.valueOf(evento.getHorario().atZone(ZONA_LOCAL).toLocalDateTime()));
            statement.setString(4, evento.getNombre());

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.eventomunicipal_actualizar " + e.getMessage(), e);
        }
    }

    @Override
    public void remove(String nombre) throws ClaseExcepciones {
        String sql = "DELETE FROM municipales WHERE nombre = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, nombre);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.eventomunicipal_eliminar " + e.getMessage(), e);
        }
    }

    @Override
    public EventoMunicipal find(String nombre) throws ClaseExcepciones {
        String sql = "SELECT * FROM municipales WHERE nombre = ?";
        EventoMunicipal evento = null;
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, nombre);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    String ubicacion = rs.getString("ubicacion");
                    String descripcion = rs.getString("descripcion");
                    // Convertir Timestamp a LocalDateTime con la zona horaria correcta
                    LocalDateTime horario = rs.getTimestamp("horario")
                            .toLocalDateTime()
                            .atZone(ZoneId.of("UTC"))
                            .withZoneSameInstant(ZONA_LOCAL)
                            .toLocalDateTime();
                    evento = new EventoMunicipal(nombre, ubicacion, descripcion, horario);
                }
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.eventomunicipal_buscar " + e.getMessage(), e);
        }
        return evento;
    }


    @Override
    public List<String> findAll() throws ClaseExcepciones {
        String sql = "SELECT * FROM municipales";
        List<String> eventosInfo = new ArrayList<>();
        try (Connection conn = ConnectionManager.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String ubicacion = rs.getString("ubicacion");
                String descripcion = rs.getString("descripcion");
                
                // Convertir Timestamp a LocalDateTime y eliminar los segundos
                LocalDateTime horario = rs.getTimestamp("horario")
                        .toLocalDateTime()
                        .atZone(ZoneId.of("UTC"))
                        .withZoneSameInstant(ZONA_LOCAL)
                        .toLocalDateTime();
                
                // Formatear el LocalDateTime para eliminar los segundos
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                String horarioFormateado = horario.format(formatter);
                
                // Formateamos la información del evento como una cadena
                String eventoInfo = String.format("Nombre: %s, Ubicación: %s, Descripción: %s, Horario: %s",
                        nombre, ubicacion, descripcion, horarioFormateado);

                // Añadimos la cadena a la lista
                eventosInfo.add(eventoInfo);
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.eventomunicipal_listar " + e.getMessage(), e);
        }
        return eventosInfo;
    }

}
