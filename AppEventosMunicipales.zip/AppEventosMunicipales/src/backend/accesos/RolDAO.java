package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Rol;

import java.util.List;

public interface RolDAO {
    void create(Rol rolUsuario, String username) throws ClaseExcepciones;

    void update(Rol rol, String usuario) throws ClaseExcepciones;

    List<Rol> findAll() throws ClaseExcepciones;

	void remove(String usuario) throws ClaseExcepciones;

	Rol find(String usuario) throws ClaseExcepciones;
}