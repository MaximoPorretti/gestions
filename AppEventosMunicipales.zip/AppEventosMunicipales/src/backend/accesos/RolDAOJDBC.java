package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Rol;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RolDAOJDBC implements RolDAO {

    @Override
    public void create(Rol rol, String usuario) throws ClaseExcepciones {
        String sql = "INSERT INTO roles (usuario, rol) VALUES (?, ?)";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, rol.getNombre());
            statement.setString(2, usuario);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.rol_crear " + e.getMessage(), e);
        }
    }

    @Override
    public void update(Rol rol, String usuario) throws ClaseExcepciones {
        String sql = "UPDATE roles SET rol = ? WHERE usuario = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, rol.getNombre());
            statement.setString(2, usuario);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.rol_actualizar " + e.getMessage(), e);
        }
    }

    @Override
    public void remove(String usuario) throws ClaseExcepciones {
        String sql = "DELETE FROM roles WHERE usuario = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, usuario);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.rol_eliminar " + e.getMessage(), e);
        }
    }

    @Override
    public Rol find(String usuario) throws ClaseExcepciones {
        String sql = "SELECT * FROM roles WHERE usuario = ?";
        Rol rol = null;
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, usuario);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    rol = new Rol(rs.getString("nombre"));
                }
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.rol_buscar " + e.getMessage(), e);
        }
        return rol;
    }

    @Override
    public List<Rol> findAll() throws ClaseExcepciones {
        String sql = "SELECT * FROM roles";
        List<Rol> roles = new ArrayList<>();
        try (Connection conn = ConnectionManager.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            while (rs.next()) {
                Rol rol = new Rol(rs.getString("usuario"));
                roles.add(rol);
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.rol_listar " + e.getMessage(), e);
        }
        return roles;
    }
}