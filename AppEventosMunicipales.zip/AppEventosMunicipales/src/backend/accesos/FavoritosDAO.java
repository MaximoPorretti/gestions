package backend.accesos;

import java.util.List;

import commons.exepciones.ClaseExcepciones;
import entities.Favorito;

public interface FavoritosDAO {
    // Crear favorito
    void createFavorito(Favorito favorito) throws ClaseExcepciones;


    // Eliminar un favorito
    void eliminarFavorito(String usuario, String nEvento) throws  ClaseExcepciones;
    
	List<Favorito> todosLosFavoritos() throws  ClaseExcepciones;


}
