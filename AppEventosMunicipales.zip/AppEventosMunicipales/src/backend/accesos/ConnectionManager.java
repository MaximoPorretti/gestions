package backend.accesos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import commons.exepciones.ClaseExcepciones;

public class ConnectionManager {
    // ResourceBundle para cargar propiedades desde database.properties
    private static final ResourceBundle dbConfig = ResourceBundle.getBundle("database");

    // Propiedades de conexión cargadas desde el archivo properties
    private static String DRIVER = dbConfig.getString("db.driver");
    private static String URL_DB = dbConfig.getString("db.url");
    private static String DB = dbConfig.getString("db.name");
    private static String USER = dbConfig.getString("db.user");
    private static String PASSWORD = dbConfig.getString("db.password");

    private static Connection conn = null;

    // Crear una nueva conexión
    private static Connection crearConnection() {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL_DB + DB, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            new ClaseExcepciones(dbConfig.getString("connection.error.driver"), e);
        } catch (SQLException sqlEx) {
            new ClaseExcepciones(dbConfig.getString("connection.error.connect") + " " + sqlEx.getMessage());
        }
        return null;
    }

    // Método para conectar a la base de datos
    public static void connect() {
        conn = crearConnection();
        if (conn != null) {
            System.out.println(dbConfig.getString("connection.success.connect"));
        }
    }

    // Método para desconectar la base de datos
    public static void disconnect() {
        if (conn != null) {
            try {
                conn.close();
                System.out.println(dbConfig.getString("connection.success.disconnect"));
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                conn = null; // aseguramos que se anule la conexión cerrada
            }
        }
    }

    // Obtener la conexión existente o reconectar si está cerrada
    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = crearConnection(); // reconectar si está cerrada
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    // Método para reconectar
    public static void reconnect() {
        disconnect();
        connect();
    }

    // Métodos para obtener y establecer el DRIVER (si es necesario)
    public static String getDRIVER() {
        return DRIVER;
    }

    public static void setDRIVER(String dRIVER) {
        DRIVER = dRIVER;
    }
}
