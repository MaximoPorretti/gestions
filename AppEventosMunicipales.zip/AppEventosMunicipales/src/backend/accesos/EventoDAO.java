package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Evento;
import entities.Usuario;

import java.util.List;

public interface EventoDAO {
    void create(Evento evento) throws ClaseExcepciones;

    void update(Evento evento) throws ClaseExcepciones;

    void remove(String nombre) throws ClaseExcepciones;

    List<String> findAll() throws ClaseExcepciones;

    List<Evento> findByUsuario(Usuario usuario) throws ClaseExcepciones;

    void updateEstado(String nombre, String nuevoEstado) throws ClaseExcepciones;

	Evento find(String nombre, Usuario usuario) throws ClaseExcepciones;
}