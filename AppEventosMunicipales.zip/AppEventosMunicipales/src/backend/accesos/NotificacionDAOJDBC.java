package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Notificacion;
import entities.Usuario;
import backend.api.PersistenceApi;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class NotificacionDAOJDBC implements NotificacionDAO {
	PersistenceApi api = new PersistenceApi(null, new EventoMunicipalDAOJDBC(), new UsuarioDAOJDBC(), new RolDAOJDBC(),null, new FavoritosDAOJDBC());

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public void create(Notificacion notificacion) throws ClaseExcepciones {
        String sql = "INSERT INTO notificacion (mensaje, usuario, fechaYhora, idnotificacion) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, notificacion.getMensaje());
            statement.setString(2, notificacion.getUsuario().getUsuario());
            statement.setString(3, notificacion.getFechaCreacion().format(FORMATTER));
            statement.setLong(4, notificacion.getId());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_crear " + e.getMessage(), e);
        }
    }

    @Override
    public void update(Notificacion notificacion) throws ClaseExcepciones {
        String sql = "UPDATE notificacion SET mensaje = ?, usuario = ?, fechaYhora = ? WHERE idnotificacion = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, notificacion.getMensaje());
            statement.setString(2, notificacion.getUsuario().getUsuario());
            statement.setString(3, notificacion.getFechaCreacion().format(FORMATTER));
            statement.setLong(4, notificacion.getId());

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_actualizar " + e.getMessage(), e);
        }
    }

    @Override
    public void remove(Long id) throws ClaseExcepciones {
        String sql = "DELETE FROM notificacion WHERE idnotificacion = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setLong(1, id);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_eliminar " + e.getMessage(), e);
        }
    }

    @Override
    public Notificacion find(Long id) throws ClaseExcepciones {
        String sql = "SELECT * FROM notificacion WHERE idnotificacion = ?";
        Notificacion notificacion = null;
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setLong(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    String mensaje = rs.getString("mensaje");
                    LocalDateTime fechaYhora = LocalDateTime.parse(rs.getString("fechaYhora"), FORMATTER);
                    String username = rs.getString("usuario");

                    // Obtener usuario utilizando el método de la API
                    Usuario usuario = api.obtenerUsuarioPorUsername(username);
                    notificacion = new Notificacion(id, mensaje, fechaYhora, usuario);
                }
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_buscar " + e.getMessage(), e);
        }
        return notificacion;
    }

    @Override
    public List<Notificacion> findAll() throws ClaseExcepciones {
        String sql = "SELECT * FROM notificacion";
        List<Notificacion> notificaciones = new ArrayList<>();
        try (Connection conn = ConnectionManager.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            while (rs.next()) {
                Long id = rs.getLong("idnotificacion");
                String mensaje = rs.getString("mensaje");
                LocalDateTime fechaYhora = LocalDateTime.parse(rs.getString("fechaYhora"), FORMATTER);
                String username = rs.getString("usuario");

                // Obtener usuario utilizando el método de la API
                Usuario usuario = api.obtenerUsuarioPorUsername(username);
                Notificacion notificacion = new Notificacion(id, mensaje, fechaYhora, usuario);
                notificaciones.add(notificacion);
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_listar " + e.getMessage(), e);
        }
        return notificaciones;
    }

    @Override
    public List<Notificacion> findByUsuario(Usuario username) throws ClaseExcepciones {
        List<Notificacion> notificaciones = new ArrayList<>();
        String sql = "SELECT * FROM notificacion WHERE usuario = ?";

        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username.getUsuario());
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Long id = rs.getLong("idnotificacion");
                    String mensaje = rs.getString("mensaje");
                    LocalDateTime fechaYhora = LocalDateTime.parse(rs.getString("fechaYhora"), FORMATTER);

               
                    Notificacion notificacion = new Notificacion(id, mensaje, fechaYhora, username);
                    notificaciones.add(notificacion);  // Agregar la notificación mientras el ResultSet está abierto
                }
            } // El ResultSet se cierra automáticamente aquí

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.notificacion_listar_usuario " + e.getMessage(), e);
        }
        return notificaciones;
    }


}
