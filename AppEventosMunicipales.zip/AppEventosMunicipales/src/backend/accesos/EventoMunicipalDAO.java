package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.EventoMunicipal;

import java.util.List;

public interface EventoMunicipalDAO {
    void create(EventoMunicipal evento) throws ClaseExcepciones;

    void update(EventoMunicipal evento) throws ClaseExcepciones;

    void remove(String nombre) throws ClaseExcepciones;

    EventoMunicipal find(String nombre) throws ClaseExcepciones;

    List<String> findAll() throws ClaseExcepciones;
}