package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Rol;
import entities.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOJDBC implements UsuarioDAO {

    @Override
    public void create(Usuario usuario) throws ClaseExcepciones {
        String sql = "INSERT INTO usuarios (usuario, contrasena, nombre, email, rol) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, usuario.getUsuario());
            statement.setString(2, usuario.getContrasena());
            statement.setString(3, usuario.getNombre());
            statement.setString(4, usuario.getEmail());
            statement.setString(5, usuario.getRol().getNombre());

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.usuario_crear" + e.getMessage(), e);
        }
    }

    @Override
    public void update(Usuario usuario) throws ClaseExcepciones {
        String sql = "UPDATE usuarios SET contrasena = ?, nombre = ?, email = ?, rol = ? WHERE usuario = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, usuario.getContrasena());
            statement.setString(2, usuario.getNombre());
            statement.setString(3, usuario.getEmail());
            statement.setString(4, usuario.getRol().getNombre());
            statement.setString(5, usuario.getUsuario());

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.usuario_actualizar " + e.getMessage(), e);
        }
    }

    @Override
    public void remove(String username) throws ClaseExcepciones {
        String sql = "DELETE FROM usuarios WHERE usuario = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, username);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.usuario_eliminar" + e.getMessage(), e);
        }
    }

    @Override
    public Usuario find(String username) throws ClaseExcepciones {
        String sql = "SELECT * FROM usuarios WHERE usuario = ?";
        Usuario usuario = null;
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, username);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    String nombre = rs.getString("nombre");
                    String email = rs.getString("email");
                    String contrasena = rs.getString("contrasena");
                    String rolNombre = rs.getString("rol");
                    Rol rol = new Rol(rolNombre);
                    usuario = new Usuario(username, contrasena, nombre, email, rol);
                }
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.usuario_buscar " + e.getMessage(), e);
        }
        return usuario;
    }

    @Override
    public List<Usuario> findAll() throws ClaseExcepciones {
        String sql = "SELECT * FROM usuarios";
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = ConnectionManager.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            while (rs.next()) {
                String username = rs.getString("usuario");
                String contrasena = rs.getString("contrasena");
                String nombre = rs.getString("nombre");
                String email = rs.getString("email");
                String rolNombre = rs.getString("rol");
                Rol rol = new Rol(rolNombre);
                Usuario usuario = new Usuario(username, contrasena, nombre, email, rol);
                usuarios.add(usuario);
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.usuario_lista " + e.getMessage(), e);
        }
        return usuarios;
    }
}