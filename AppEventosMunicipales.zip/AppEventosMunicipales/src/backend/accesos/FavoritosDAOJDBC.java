package backend.accesos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import commons.exepciones.ClaseExcepciones;

import entities.Favorito;
import entities.Evento;
import entities.Usuario;

public class FavoritosDAOJDBC implements FavoritosDAO {
    @Override
    public void createFavorito(Favorito nuevoFavorito) throws ClaseExcepciones {
        String query = "INSERT INTO favoritos (usuario, evento) VALUES (?, ?)";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nuevoFavorito.getUsuario().getUsuario());
            stmt.setString(2, nuevoFavorito.getEvento().getNombre());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected <= 0) {
                throw new ClaseExcepciones("error.favorito_registrar");
            }
        } catch (SQLException e) {
            throw new ClaseExcepciones("error.favorito_registrar_BD", e);
        }
    }

    @Override
    public void eliminarFavorito(String usuario, String nEvento) throws ClaseExcepciones {
        String query = "DELETE FROM favoritos WHERE usuario = ? AND evento = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, usuario);
            stmt.setString(2, nEvento);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClaseExcepciones("error.favorito_eliminar_no_encontrado");
            }
        } catch (SQLException e) {
            throw new ClaseExcepciones("error.favorito_eliminar", e);
        }
    }

    @Override
    public List<Favorito> todosLosFavoritos() throws ClaseExcepciones {
        List<Favorito> favoritos = new ArrayList<>();
        String query = "SELECT * FROM favoritos";

        try (Connection connection = ConnectionManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            // Crear listas temporales para usuarios y eventos
            List<String> usuariosNombres = new ArrayList<>();
            List<String> eventosNombres = new ArrayList<>();

            // Recorrer el ResultSet y llenar las listas temporales
            while (rs.next()) {
                usuariosNombres.add(rs.getString("usuario"));
                eventosNombres.add(rs.getString("evento"));
            }

            // Recuperar usuarios y eventos después de cerrar el ResultSet
            UsuarioDAOJDBC usuarioDao = new UsuarioDAOJDBC();
            EventoDAOJDBC eventoDao = new EventoDAOJDBC();

            for (int i = 0; i < usuariosNombres.size(); i++) {
                try {
                    Usuario usuario = usuarioDao.find(usuariosNombres.get(i));
                    Evento evento = eventoDao.find(eventosNombres.get(i), usuario);

                    if (usuario != null && evento != null) {
                        favoritos.add(new Favorito(usuario, evento));
                    }
                } catch (ClaseExcepciones e) {
                    System.err.println("error.favorito_listar_usuario_evento " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            throw new ClaseExcepciones("error.favorito_listar_evento", e);
        }
        return favoritos;
    }
}