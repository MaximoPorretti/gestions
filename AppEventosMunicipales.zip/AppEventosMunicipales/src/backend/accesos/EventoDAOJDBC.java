package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Evento;
import entities.EventoMunicipal;
import entities.Favorito;
import entities.Usuario;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import backend.api.PersistenceApi;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class EventoDAOJDBC implements EventoDAO {


	    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	    private static final ZoneId ZONA_LOCAL = ZoneId.of("America/Argentina/Buenos_Aires"); // Ajuste de zona horaria

	    @Override
	    public void create(Evento evento) throws ClaseExcepciones {
	        String sql = "INSERT INTO eventos (nombre, ubicacion, descripcion, horario, estado, etiqueta, usuario) VALUES (?, ?, ?, ?,?, ?, ?)";
	        try (Connection conn = ConnectionManager.getConnection();
	             PreparedStatement statement = conn.prepareStatement(sql)) {

	            statement.setString(1, evento.getNombre());
	            statement.setString(2, evento.getUbicacion());
	            statement.setString(3, evento.getDescripcion());
	            // Convertir LocalDateTime a Timestamp con zona horaria ajustada
	            statement.setTimestamp(4, Timestamp.valueOf(evento.getHorario().atZone(ZONA_LOCAL).toLocalDateTime()));
	            statement.setString(5, evento.getEstado());
	            statement.setString(6, evento.getEtiqueta());
	            statement.setString(7, evento.getUsuario().getUsuario()); // Obtener identificador del Usuario

	            statement.executeUpdate();

	        } catch (SQLException e) {
	            throw new ClaseExcepciones("error.evento_crear " + e.getMessage(), e);
	        }
	    }

    @Override
    public void update(Evento evento) throws ClaseExcepciones {
        String sql = "UPDATE eventos SET ubicacion = ?, descripcion = ?, etiqueta = ?, horario = ?, estado = ? WHERE nombre = ? AND usuario = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, evento.getUbicacion());
            statement.setString(2, evento.getDescripcion());
            statement.setString(3, evento.getEtiqueta());
            statement.setTimestamp(4, Timestamp.valueOf(evento.getHorario().atZone(ZONA_LOCAL).toLocalDateTime()));
            statement.setString(5, evento.getEstado());
            statement.setString(6, evento.getNombre());
            statement.setString(7, evento.getUsuario().getUsuario()); // Obtener identificador del Usuario

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.evento_actualizar " + e.getMessage(), e);
        }
    }

    @Override
    public void remove(String nombre) throws ClaseExcepciones {
        String sql = "DELETE FROM eventos WHERE nombre = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, nombre);
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.evento_eliminar " + e.getMessage(), e);
        }
    }

    @Override
    public Evento find(String nombre, Usuario usuario) throws ClaseExcepciones {
        String sql = "SELECT * FROM eventos WHERE nombre = ?";
        Evento evento = null;
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, nombre);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    String etiqueta = rs.getString("etiqueta");
                    String descripcion = rs.getString("descripcion");
                    String ubicacion = rs.getString("ubicacion");
                    LocalDateTime horario = rs.getTimestamp("horario")
                            .toLocalDateTime()
                            .atZone(ZoneId.of("UTC"))
                            .withZoneSameInstant(ZONA_LOCAL)
                            .toLocalDateTime();
                    String estado = rs.getString("estado");
                   
                    // Creamos el evento usando los valores recuperados
                    evento = new Evento(nombre, ubicacion, descripcion, etiqueta, usuario, horario, estado);
                }
            }
        } catch (SQLException e) {
            throw new ClaseExcepciones("error.evento_buscar " + e.getMessage(), e);
        }
        return evento;
    }
    @Override
    public List<String> findAll() throws ClaseExcepciones {
        List<String> eventosInfo = new ArrayList<>();
        String query = "SELECT * FROM eventos";  // Consulta para obtener todos los eventos

        try (Connection conn = ConnectionManager.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            // Recorrer el ResultSet y almacenar los datos de los eventos
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String ubicacion = rs.getString("ubicacion");
                String descripcion = rs.getString("descripcion");

                // Convertir Timestamp a LocalDateTime y ajustar la zona horaria
                LocalDateTime horario = rs.getTimestamp("horario")
                        .toLocalDateTime()
                        .atZone(ZoneId.of("UTC"))
                        .withZoneSameInstant(ZONA_LOCAL)
                        .toLocalDateTime();

                // Formatear el LocalDateTime para eliminar los segundos
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                String horarioFormateado = horario.format(formatter);

                // Obtener el estado, etiqueta y usuario
                String etiqueta = rs.getString("etiqueta");
                String estado = rs.getString("estado");
                String usuario = rs.getString("usuario");

                // Formateamos la información del evento como una cadena
                String eventoInfo = String.format("Nombre: %s, Ubicación: %s, Descripción: %s, Horario: %s, Estado: %s, Etiqueta: %s, Usuario: %s",
                        nombre, ubicacion, descripcion, horarioFormateado, estado, etiqueta, usuario);

                // Añadimos la cadena a la lista
                eventosInfo.add(eventoInfo);
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("error.evento_listar " + e.getMessage(), e);
        }
        return eventosInfo;
    }



    @Override
    public List<Evento> findByUsuario(Usuario usuario) throws ClaseExcepciones {
        String sql = "SELECT * FROM eventos WHERE usuario = ?";
        List<Evento> eventos = new ArrayList<>();
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, usuario.getUsuario());
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    String nombre = rs.getString("nombre");
                    String etiqueta = rs.getString("etiqueta");
                    String descripcion = rs.getString("descripcion");
                    String ubicacion = rs.getString("ubicacion");
                    LocalDateTime horario = rs.getTimestamp("horario")
                            .toLocalDateTime()
                            .atZone(ZoneId.of("UTC"))
                            .withZoneSameInstant(ZONA_LOCAL)
                            .toLocalDateTime();
                    String estado = rs.getString("estado");

                    Evento evento = new Evento(nombre, ubicacion, descripcion, etiqueta, usuario, horario, estado);
                    eventos.add(evento);
                }
            }

        } catch (SQLException e) {
            throw new ClaseExcepciones("Error al listar los eventos del usuario: " + e.getMessage(), e);
        }
        return eventos;
    }

    @Override
    public void updateEstado(String nombre, String nuevoEstado) throws ClaseExcepciones {
        String sql = "UPDATE eventos SET estado = ? WHERE nombre = ?";
        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setString(1, nuevoEstado);
            statement.setString(2, nombre);

            statement.executeUpdate();

        } catch (SQLException e) {
            throw new ClaseExcepciones("Error al actualizar el estado del evento: " + e.getMessage(), e);
        }
    }
}
