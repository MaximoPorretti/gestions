package backend.accesos;

import commons.exepciones.ClaseExcepciones;
import entities.Usuario;

import java.util.List;

import backend.dto.UsuarioDTO;

public interface UsuarioDAO {
    void create(Usuario usuario) throws ClaseExcepciones;

    void update(Usuario usuario) throws ClaseExcepciones;

    void remove(String username) throws ClaseExcepciones;

    Usuario find(String username) throws ClaseExcepciones;

    List<Usuario> findAll() throws ClaseExcepciones;

	
}