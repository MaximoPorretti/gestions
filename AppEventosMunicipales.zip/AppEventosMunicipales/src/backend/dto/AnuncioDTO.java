package backend.dto;

public class AnuncioDTO{
	 private String nombre;
	    private String descripcion;
	    private Integer monto;

	    // Constructor
	    public AnuncioDTO(String nombre, String descripcion, Integer monto) {
	        this.nombre = nombre;
	        this.descripcion = descripcion;
	        this.monto = monto;
	    }

	    // Getters y setters
	    public String getNombre() {
	        return nombre;
	    }

	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }

	    public String getDescripcion() {
	        return descripcion;
	    }

	    public void setDescripcion(String descripcion) {
	        this.descripcion = descripcion;
	    }

	    public Integer getMonto() {
	        return monto;
	    }

	    public void setMonto(Integer monto) {
	        this.monto = monto;
	    }
	}