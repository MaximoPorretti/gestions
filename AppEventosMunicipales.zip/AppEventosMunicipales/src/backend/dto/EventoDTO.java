package backend.dto;

import commons.exepciones.ClaseExcepciones;
import java.time.LocalDateTime;

public class EventoDTO {
    private String nombre;
    private String ubicacion;
    private String descripcion;
    private String etiqueta;
    private UsuarioDTO usuario;
    private LocalDateTime horario;
    private String estado;

    public EventoDTO(String nombre, String ubicacion, String descripcion, String etiqueta, LocalDateTime horario, UsuarioDTO usuario, String estado) throws ClaseExcepciones {
        validarDatos(nombre, ubicacion, descripcion, horario);
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
        this.etiqueta = etiqueta;
        this.usuario = usuario;
        this.horario = horario;
        this.estado = estado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        validarCampo(nombre, "nombre");
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) throws ClaseExcepciones {
        validarCampo(ubicacion, "ubicacion");
        this.ubicacion = ubicacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) throws ClaseExcepciones {
        validarCampo(descripcion, "descripcion");
        this.descripcion = descripcion;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    public void setEtiqueta(String etiqueta) throws ClaseExcepciones {
        validarCampo(etiqueta, "etiqueta");
        this.etiqueta = etiqueta;
    }

    public UsuarioDTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioDTO usuario) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_invalido");
        }
        this.usuario = usuario;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    public void setHorario(LocalDateTime horario) throws ClaseExcepciones {
        if (horario == null) {
            throw new ClaseExcepciones("error_horario_invalido");
        }
        this.horario = horario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) throws ClaseExcepciones {
        validarCampo(estado, "estado");
        this.estado = estado;
    }

    private void validarDatos(String nombre, String ubicacion, String descripcion, LocalDateTime horario) throws ClaseExcepciones {
        if (nombre == null || nombre.trim().isEmpty() ||
            ubicacion == null || ubicacion.trim().isEmpty() ||
            descripcion == null || descripcion.trim().isEmpty() ||
            horario == null) {
            throw new ClaseExcepciones("error.parametro_invalido");
        }
    }

    private void validarCampo(String valor, String campo) throws ClaseExcepciones {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ClaseExcepciones("error." + campo + "_invalido");
        }
    }

    @Override
    public String toString() {
        return String.format("EventoDTO[nombre=%s, ubicacion=%s, descripcion=%s, etiqueta=%s, horario=%s, usuario=%s, estado=%s]",
                nombre, ubicacion, descripcion, etiqueta, horario, usuario, estado);
    }
}