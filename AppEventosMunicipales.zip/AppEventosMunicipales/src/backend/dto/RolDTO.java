package backend.dto;

public class RolDTO {
    private String nombre;

    public RolDTO(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("error.nombre_rol_null");
        }
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("error.nombre_rol_null");
        }
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return String.format("RolDTO[nombre='%s']", nombre);
    }
}