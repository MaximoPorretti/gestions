package backend.dto;

import commons.exepciones.ClaseExcepciones;


public class UsuarioDTO {
    private String usuario;
    private String nombre;
    private String email;
    private RolDTO rol;

    public UsuarioDTO(String usuario, String nombre, String email, RolDTO rol) throws ClaseExcepciones {
        validarDatos(usuario, nombre, email);
        if (rol == null) {
            throw new ClaseExcepciones("error.rol_null");
        }
        this.usuario = usuario;
        this.nombre = nombre;
        this.email = email;
        this.rol = rol;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) throws ClaseExcepciones {
        validarCampo(usuario, "usuario");
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ClaseExcepciones {
        validarCampo(nombre, "nombre");
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws ClaseExcepciones {
        validarCampo(email, "email");
        this.email = email;
    }

    public RolDTO getRol() {
        return rol;
    }

    public void setRol(RolDTO rol) throws ClaseExcepciones {
        if (rol == null) {
            throw new ClaseExcepciones("error.rol_null");
        }
        this.rol = rol;
    }

    private void validarDatos(String... valores) throws ClaseExcepciones {
        for (String valor : valores) {
            if (valor == null || valor.trim().isEmpty()) {
                throw new ClaseExcepciones("error.parametro_invalido");
            }
        }
    }

    private void validarCampo(String valor, String campo) throws ClaseExcepciones {
        if (valor == null || valor.trim().isEmpty()) {
            throw new ClaseExcepciones("error." + campo + "_invalido");
        }
    }

    @Override
    public String toString() {
        return "UsuarioDTO [usuario=" + usuario + ", nombre=" + nombre + ", email=" + email + ", rol=" + rol + "]";
    }
}