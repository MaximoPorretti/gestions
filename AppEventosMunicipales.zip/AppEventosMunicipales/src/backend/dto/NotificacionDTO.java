package backend.dto;

import commons.exepciones.ClaseExcepciones;
import java.time.LocalDateTime;

public class NotificacionDTO {
    private long id;
    private String mensaje;
    private LocalDateTime fechaCreacion;
    private UsuarioDTO usuario;

    public NotificacionDTO(long id, String mensaje, LocalDateTime fechaCreacion, UsuarioDTO usuario) throws ClaseExcepciones {
        validarDatos(id, mensaje, fechaCreacion, usuario);
        this.id = id;
        this.mensaje = mensaje;
        this.fechaCreacion = fechaCreacion;
        this.usuario = usuario;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        if (id <= 0) {
            throw new IllegalArgumentException("error.id_invalido");
        }
        this.id = id;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        if (mensaje == null || mensaje.isEmpty()) {
            throw new IllegalArgumentException("error.mensaje_null");
        }
        this.mensaje = mensaje;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        if (fechaCreacion == null) {
            throw new IllegalArgumentException("error.fecha_creacion_null");
        }
        this.fechaCreacion = fechaCreacion;
    }

    public UsuarioDTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioDTO usuario) {
        if (usuario == null) {
            throw new IllegalArgumentException("error.usuario_null");
        }
        this.usuario = usuario;
    }

    private void validarDatos(long id, String mensaje, LocalDateTime fechaCreacion, UsuarioDTO usuario) {
        if (id <= 0 || mensaje == null || mensaje.isEmpty() || fechaCreacion == null || usuario == null) {
            throw new IllegalArgumentException("error.campo_null");
        }
    }

    @Override
    public String toString() {
        return String.format("NotificacionDTO[id=%d, mensaje='%s', fechaCreacion='%s', usuario='%s']",
                id, mensaje, fechaCreacion, usuario);
    }
}