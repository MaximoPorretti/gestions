package backend.dto;

import commons.exepciones.ClaseExcepciones;

public class FavoritoDTO {
    private UsuarioDTO usuario;
    private EventoDTO evento;

    public FavoritoDTO(UsuarioDTO usuario, EventoDTO evento) throws ClaseExcepciones {
        validarDatos(usuario, evento);
        this.usuario = usuario;
        this.evento = evento;
    }

    public UsuarioDTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioDTO usuario) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        this.usuario = usuario;
    }

    public EventoDTO getEvento() {
        return evento;
    }

    public void setEvento(EventoDTO evento) throws ClaseExcepciones {
        if (evento == null) {
            throw new ClaseExcepciones("error.evento_null");
        }
        this.evento = evento;
    }

    private void validarDatos(UsuarioDTO usuario, EventoDTO evento) throws ClaseExcepciones {
        if (usuario == null) {
            throw new ClaseExcepciones("error.usuario_null");
        }
        if (evento == null) {
            throw new ClaseExcepciones("error.evento_null");
        }
    }

    @Override
    public String toString() {
        return String.format("FavoritoDTO[usuario=%s, evento=%s]", usuario, evento);
    }
}